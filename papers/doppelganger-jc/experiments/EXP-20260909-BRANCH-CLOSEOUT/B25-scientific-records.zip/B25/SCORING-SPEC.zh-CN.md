# B25 冻结评分与主端点

scoring.py与score_b09.py逐字复用B24；endpoint/cell/linear函数从B24最终版本原字节迁移。ROLE唯一对象/字段且两人属于本题名单才分R/NON_R；名单外、未知、null/字符串null、缺失歧义为U_R。人物集合、方向、字段、格式、语言分开，发生/完整记录N/A。CHOICE严格A/B、双序CC=C、WW=W、混合顺序U、解析U独立。NOT_RUN和未知启动不是U。

ORIGINAL 240记录保留完整旧对象，不回改B24原分。SWAP 240科学位置、CALIBRATION 24核验位置分开。回答账本744行：360旧真实缓存+384新计划，不当独立n。所有120来源×2任务保留原新转移和新增害，包括NO/D−，人物集合与完整raw由各原始评分和调用引用追溯。

G仅ROLE NO/D+，M1/M2各n12。Fraction严格保守上下界；上界<0且24校准PASS、主位置完整才T_G_FLIP；上界=0为false，校准/主位置缺失为NOT_ESTIMABLE/null。另算G_swap−G_original，识别界非置信区间。六词、两位置G和符号分布全部描述，不增加覆盖门槛。ROLE SINGLE和YES保护、CHOICE所有保护单列，不合并进主标签；基础或保护损坏限制解释。

check_b25.py实际调用同一评分/分析/门控函数，覆盖R/U、符号与严格零边界、技术缺失、控制分离、哈希与消息身份。check_real_runner.py以显式假tensor/model执行真实run_batch.run路径及validate_runtime，分别验证同一次加载384调用和失配后24校准/0SWAP，全为合成测试，研究forward为0。
