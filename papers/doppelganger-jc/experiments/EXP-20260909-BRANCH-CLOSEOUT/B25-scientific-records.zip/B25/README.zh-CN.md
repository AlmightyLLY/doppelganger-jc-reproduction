# B25 名单换序诊断：最终科学公开包

本包于 2026-09-09 从 B25 冻结记录与正式协调报告整理。公开包准备已经完成；制作过程没有运行模型、修改来源原件、执行 Git 或上传。最终发布由 Main 单独处理。

## 数据与身份

完整保留 **384 次实际新回答、2,496 次新 forwards**：24 次原名单校准加 360 次名单换序。另有 **360 条 B24 真实缓存**，其 raw、messages、token、调用计划和 240 个旧评分对象与 B24 逐项一致，不能算 B25 新生成。120 个语义来源都是 B24 已暴露的开发材料。

全包含 744 个新旧回答视图、480 个科学评分位置和 24 个校准位置；这些不是独立样本量。`BASELINES.json`、全部实际输入、`analysis-v1/RAW-RESPONSES.json` 及 `formal-v1/` 的 11 个冻结结果 JSON 均为原文件逐字节副本。完整源文、真实消息、渲染提示、input/generated tokens、失败或未决类别及新增损害均保留。

本批新 raw SHA256：

```text
92cdb46d9c63c874f57dd29d9cd035e759e3872916be73c437645ffc996d85fd
```

原始新旧回答的逐调用内容哈希见 `RAW-PROMPT-RESPONSE-INTEGRITY.json`；缓存来源和名单行唯一变更核对见 `CACHE-IDENTITY-VERIFICATION.json`。离线全计划和缓存中有作者参考，不是运行器模型上下文；剥离参考的 `EXECUTION-INPUTS.json` 与冻结 messages 逐条一致。

## 冻结结果与边界

24 条实际校准的消息、原生输入、渲染提示、回答文本和完整生成 token/EOS 与历史值一致。`CALIBRATION-CONTROL.PUBLIC.json` 仅重命名原独立校准核对文件，内容字节没有改动。此校准只复验指定的 24 条 ROLE 主挑战，不能称全部 360 条缓存都重新生成一致。

预写主要标签 **T_G_FLIP=true**：NO 目标、肯定干扰下的 ROLE 映射反转率差 G 从 +0.50 到 −0.50，变化量 −1.00。这不是准确率提高 100 个百分点；本次分类未决识别界不是抽样置信区间。

ROLE 从 108C12W 到 112C8W，有 8 次救回、4 次新增害。CHOICE 从 112C2W6U 到 112C0W8U，正确数未增加；8 个新 U 均为固定 A 导致的双序不一致，不能记为稳定修复。基本 ROLE 控制保持，CHOICE 否定上下文保护参考线仍未达到。

换序后五词 G 为负，但只有三词从正转负，另两词由零转负，一词零不变；详见 `LEXICAL-G-SIGN-TRANSITIONS.PUBLIC.json`。正式科学解释、反例与允许主张见 `RESULT-ANALYSIS.PUBLIC.zh-CN.md`。这支持当前模型、材料和两种名单顺序下的局部行为干预结论，不识别内部模块、抽象排名机制、跨模型规律或通用修复。独立人工 gold 为 0。

## 公开复算

Python 3 标准库即可运行，输出目录必须尚不存在：

```text
python recompute.py --raw analysis-v1/RAW-RESPONSES.json --calibration analysis-v1/CALIBRATION-CONTROL.PUBLIC.json --output recomputed_scores
```

入口先从真实已完成校准行重算身份检查，再调用原冻结评分脚本，保留真实技术未运行和不可估计规则，只向新目录写结果。已经独立执行一次：**24 条校准通过，11 个正式 JSON 全部逐字节一致**，模型调用为零，见 `RECOMPUTATION-VERIFICATION.json`。正式报告到达后仅核验未变的依赖和结果哈希，没有重复这次复算。

这验证公开数据可重现既有校准身份与描述性评分，不验证独立人工 gold，也不独立证明同一模型进程执行。模型权重、tokenizer 实体、环境锁和运行驱动不随包公开，不能承诺完整推理跨环境逐字节重现。运行前合成检查记录保留其历史身份，不当成实际模型输出或完整公开运行链的复现。

## 公开派生、原件与清单

科学输入、原始回答、缓存、校准哈希、评分和纯控制代码保持原字节。两个协议摘录与正式结果摘录均标明公开派生及原文行范围；个人交付入口、机器环境和运行组织内容未摘录。`INFERENCE-SPEC.PUBLIC.json` 仅保留模型身份、revision、文件内容哈希及科学推理规则。

四个前后 Word/Excel 原件只登记去路径的内容 SHA256 和未审核事实，见 `PRIVATE-ARTIFACT-HASHES.PUBLIC.json`。24 格本人意见仍空；没有提取或公开文档内容。正式协调收尾凭据的公开派生见 `COORDINATOR-CLOSEOUT.PUBLIC.json`。

`SOURCE-PUBLIC-MANIFEST.json` 逐文件列出仓库相对来源、原始/公开 SHA256、字节数及转换；自身与 `MANIFEST-SHA256.txt` 之外的全部公开文件均纳入，后者单独记录清单哈希。原冻结分数未覆写。中间公开准备说明已保留在本地准备历史中，其内容哈希及省略原因见 `OMISSIONS.json`；当前包状态以 `LEDGER.json` 和 `PUBLICATION-VALIDATION.json` 为准。

本人原件、人审笔记、机器环境、账户和绝对路径、连接或执行日志、其他私有/封存材料不在本包。实际科学提示和回答没有因公开整理删字；隐私冲突规则是停止公开相应文件并登记，不能改写科学内容。今日止于 B25，没有新增 B26。
