"""Frozen B25 offline scoring. Cached B24 records are preserved, never overwritten."""
from pathlib import Path
from collections import Counter
from fractions import Fraction as F
import json,sys,copy
from scoring import role_score,choice_score,choice_pair,transition
P=Path(__file__).resolve().parent
def endpoint(role,call):
 # Exact named reverse can be recognized even when a response contains extra prose.
 # Preserve B23 scoring; do not turn a clearly different named pair into target reversal.
 pair=[role['raw_fields'].get(k) for k in ['actor','undergoer']]
 readable=role['unique_readable_object'] and all(role['field_identity_reasons'][k]=='UNIQUE' for k in ['actor','undergoer']) and all(isinstance(v,str) and v in call['entity_map'].values() for v in pair)
 if not readable:return dict(reversal='U_R',reversal_reason='NON_ROSTER_OR_UNREADABLE_OR_NONUNIQUE_FIELD',raw_pair=pair,unique_readable_object=role['unique_readable_object'],field_identity_reasons=role['field_identity_reasons'],non_roster_fields=[k for k,v in zip(['actor','undergoer'],pair) if not isinstance(v,str) or v not in call['entity_map'].values()])
 return dict(reversal='R' if pair==call['target_pair'][::-1] else 'NON_R',reversal_reason='EXACT_TARGET_REVERSED' if pair==call['target_pair'][::-1] else 'OTHER_READABLE_PAIR',raw_pair=pair)
def cell(rows):
 c=Counter(r['label'] for r in rows);e=Counter(r['reversal'] for r in rows);n=len(rows);miss=sum(r['status']!='COMPLETE' for r in rows)
 assert n and e['R']+e['NON_R']+e['U_R']+miss==n
 return dict(n=n,C=c['C'],W=c['W'],U=c['U'],not_scored=miss,R=e['R'],NON_R=e['NON_R'],U_R=e['U_R'],status='INCOMPLETE_TECHNICAL' if miss else 'COMPLETE',lower=None if miss else e['R']/n,upper=None if miss else (e['R']+e['U_R'])/n)
def linear(cells,coefficients):
 selected=[(k,cells[k],a) for k,a in coefficients.items()]
 if any(c['status']!='COMPLETE' for k,c,a in selected):return dict(status='INCOMPLETE_TECHNICAL',point=None,lower=None,upper=None,lower_exact=None,upper_exact=None)
 point=sum((a*F(c['R'],c['n']) for k,c,a in selected),F(0));lo=sum((a*F(c['R']+(c['U_R'] if a<0 else 0),c['n']) for k,c,a in selected),F(0));hi=sum((a*F(c['R']+(c['U_R'] if a>0 else 0),c['n']) for k,c,a in selected),F(0))
 return dict(status='COMPLETE',point=float(point),lower=float(lo),upper=float(hi),lower_exact=str(lo),upper_exact=str(hi),point_identity='OBSERVED_R_LINEAR_CONTRAST_NOT_IMPUTED_U',interval_identity='CLASSIFICATION_IDENTIFICATION_NOT_CONFIDENCE_INTERVAL')

def g_contrast(rows):
 challenge=[r for r in rows if r['task']=='ROLE_ONLY' and r['fact']=='NO' and r['distractor_fact']=='YES']
 cells={m:cell([r for r in challenge if r['mapping_id']==m]) for m in ['M1','M2']}
 return dict(cells=cells,G=linear(cells,{'M1':1,'M2':-1}))
def flip(calibration_passed,g):
 if calibration_passed is not True or g['status']!='COMPLETE':return dict(status='NOT_ESTIMABLE',T_G_FLIP=None)
 return dict(status='COMPLETE',T_G_FLIP=F(g['upper_exact'])<0)
def summarize(records,calibration_passed):
 versions={}
 for variant in ['ORIGINAL','SWAP']:
  rr=[r for r in records if r['variant']==variant]
  summary=g_contrast(rr);assert summary['cells']['M1']['n']==summary['cells']['M2']['n']==12
  summary['families']={f:g_contrast([r for r in rr if r['lexical_family']==f]) for f in sorted({r['lexical_family'] for r in rr})}
  summary['positions']={f:g_contrast([r for r in rr if r['position']==f]) for f in ['TARGET_FIRST','TARGET_LAST']}
  summary['family_sign_counts']=dict(Counter('INCOMPLETE' if v['G']['status']!='COMPLETE' else 'positive' if F(v['G']['lower_exact'])>0 else 'negative' if F(v['G']['upper_exact'])<0 else 'zero' if v['G']['lower_exact']==v['G']['upper_exact']=='0' else 'includes_zero' for v in summary['families'].values()))
  summary['controls']={}
  for task in ['ROLE_ONLY','CHOICE']:
   for fact in ['YES','NO']:
    for condition in ['SINGLE','CROSS_ACTOR']:
     ss=[r for r in rr if (r['task'],r['fact'],r['condition'])==(task,fact,condition)]
     c=cell(ss);threshold=11 if condition=='SINGLE' else 46 if task=='CHOICE' or fact=='YES' else None
     summary['controls'][task+'_'+fact+'_'+condition]=dict(**c,reference_min_C=threshold,reference_pass=None if threshold is None or c['not_scored'] else c['C']>=threshold)
  versions[variant]=summary
 old,new=versions['ORIGINAL']['G'],versions['SWAP']['G'];tag=flip(calibration_passed,new)
 delta=dict(status='NOT_ESTIMABLE',lower=None,upper=None,lower_exact=None,upper_exact=None)
 if calibration_passed and old['status']==new['status']=='COMPLETE':
  lo=F(new['lower_exact'])-F(old['upper_exact']);hi=F(new['upper_exact'])-F(old['lower_exact']);delta=dict(status='COMPLETE',lower=float(lo),upper=float(hi),lower_exact=str(lo),upper_exact=str(hi))
 return dict(variants=versions,primary=tag,G_swap_minus_original=delta,interpretation='ROLE_PRIMARY_CONTROL_AND_CHOICE_SECONDARY_SEPARATE; IDENTIFICATION_NOT_CONFIDENCE_INTERVAL')
def analyze(raw,calibration,started_call_ids=None):
 load=lambda n:json.loads((P/n).read_text());calls=load('DERIVED-CALL-PLAN.json')['calls'];base=load('BASELINES.json');sources=load('SOURCE-POSITIONS.json')['sources'];src={s['source_id']:s for s in sources}
 lookup={c['call_id']:c for c in calls};actual={r['call_id']:r for r in raw};assert len(raw)==len(actual) and set(actual)<=set(lookup);started=set(actual if started_call_ids is None else started_call_ids);assert set(actual)<=started<=set(lookup)
 passed=calibration.get('calibration_passed') is True
 if passed:assert len(calibration['checks'])==24 and all(x['pass'] for x in calibration['checks'])
 else:assert not any(lookup[i]['phase']=='SWAP' for i in started),'Swap started despite failed calibration'
 answers=[];scored={};calibration_rows=[]
 for c in calls:
  r=actual.get(c['call_id']);sc=None
  if r is not None:
   assert r['messages']==c['messages'] and r['prompt_sha256']==c['prompt_sha256'] and isinstance(r['generated_text'],str)
   sc=role_score(r['generated_text'],c) if c['task']=='ROLE_ONLY' else choice_score(r['generated_text'],c['correct_option'])
  status='COMPLETE' if r is not None else 'STARTED_UNKNOWN' if c['call_id'] in started else 'NOT_RUN_CALIBRATION_FAILED' if c['phase']=='SWAP' and not passed else 'NOT_RUN'
  ans=dict(plan=c,status=status,actual=r,score=sc,variant=c['phase'],identity='NEW_MODEL_OUTPUT' if r else 'PLANNED_UNRUN_OR_INCOMPLETE');answers.append(ans);scored[c['call_id']]=sc
  if c['phase']=='CALIBRATION':calibration_rows.append(dict(call_id=c['call_id'],source_id=c['source_id'],status=status,score=sc,hash_check=next((x for x in calibration.get('checks',[]) if x['call_id']==c['call_id']),None)))
 for c,r in zip(base['call_plan'],base['rows']):
  assert c['call_id']==r['call_id'];answers.append(dict(plan=c,status='COMPLETE',actual=r,score=None,variant='ORIGINAL',identity='B24_REAL_CACHE_NOT_NEW_GENERATION'))
 records=[]
 for old in base['records']:
  r=copy.deepcopy(old);r.update(variant='ORIGINAL',parent_source_id=old['source_id'],source_id=base['source_id_map'][old['source_id']],original_record=old);records.append(r)
 for s in sources:
  cs=[c for c in calls if c['phase']=='SWAP' and c['source_id']==s['source_id']];rc=next(c for c in cs if c['task']=='ROLE_ONLY');ac=next(c for c in cs if c['correct_option']=='A');bc=next(c for c in cs if c['correct_option']=='B');role=scored[rc['call_id']]
  meta={k:s[k] for k in ['source_id','parent_source_id','base_id','lexical_family','cohort','mapping_id','fact','condition','position','distractor_fact']};meta['variant']='SWAP'
  st=next(a['status'] for a in answers if a['plan']['call_id']==rc['call_id']);rr=dict(**meta,task='ROLE_ONLY',status=st,label=role['labels']['participant'] if role else None,score=role,call_ids=[rc['call_id']],**(endpoint(role,rc) if role else dict(reversal=None)));records.append(rr)
  cp=choice_pair(scored[ac['call_id']],scored[bc['call_id']])
  if cp['status']!='COMPLETE':cp['status']='INCOMPLETE_TECHNICAL' if any(c['call_id'] in started for c in [ac,bc]) else 'NOT_RUN_CALIBRATION_FAILED' if not passed else 'NOT_RUN'
  records.append(dict(**meta,task='CHOICE',**cp,call_ids=[ac['call_id'],bc['call_id']],reversal={'C':'NON_R','W':'R','U':'U_R',None:None}[cp['label']]))
 assert len(answers)==744 and len(records)==480 and len(calibration_rows)==24
 result=summarize(records,passed);transitions=[];paired=[]
 for s in sources:
  for task in ['ROLE_ONLY','CHOICE']:
   old=next(r for r in records if r['variant']=='ORIGINAL' and r['source_id']==s['source_id'] and r['task']==task);new=next(r for r in records if r['variant']=='SWAP' and r['source_id']==s['source_id'] and r['task']==task)
   transitions.append(dict(source_id=s['source_id'],task=task,fact=s['fact'],distractor_fact=s['distractor_fact'],position=s['position'],mapping_id=s['mapping_id'],lexical_family=s['lexical_family'],status=new['status'],transition=transition(old['label'],new['label']) if new['status']=='COMPLETE' else None,original_reversal=old['reversal'],swap_reversal=new['reversal'],new_harm=old['label']=='C' and new['label'] in ['W','U'] if new['status']=='COMPLETE' else None,original_record=old,swap_record=new))
   paired.append(dict(source_id=s['source_id'],task=task,original=old,swap=new))
 result.update(answers=answers,records=records,calibration=calibration_rows,transitions=transitions,paired=paired,identity='AI_PROSPECTIVE_PRESENTATION_INTERVENTION_EXPOSED_DEVELOPMENT_NOT_HUMAN_GOLD',no_extra_scientific_calls=True)
 return result
if __name__=='__main__':
 payload=json.loads(Path(sys.argv[1]).read_text());cal=json.loads(Path(sys.argv[2]).read_text());out=Path(sys.argv[3]);out.mkdir(exist_ok=False)
 for k,v in analyze(payload['rows'],cal,payload.get('started_call_ids')).items():(out/(k.upper()+'.AI.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
