"""Control-only same-process stage gate. Historical answer bodies are never needed."""
import hashlib,json
FIELDS=('prompt_sha256','rendered_prefix_sha256','input_ids_sha256','generated_text_sha256','generated_token_ids_sha256')
def th(v):return hashlib.sha256(v.encode('utf8')).hexdigest()
def jh(v):return th(json.dumps(v,ensure_ascii=False,separators=(',',':')))
def identity(row,expected,output=True):
 problems=[]
 if row.get('call_id')!=expected['call_id'] or row.get('parent_call_id')!=expected['parent_call_id']:problems.append('call_identity')
 messages=row.get('messages');valid=isinstance(messages,list) and len(messages)==1 and set(messages[0])=={'role','content'} and messages[0]['role']=='user'
 if not valid:problems.append('messages')
 actual={'prompt_sha256':th(messages[0]['content']) if valid else None,'rendered_prefix_sha256':th(row['rendered_prefix']) if isinstance(row.get('rendered_prefix'),str) else None,'input_ids_sha256':jh(row['input_ids']) if isinstance(row.get('input_ids'),list) else None}
 if output:
  actual.update(generated_text_sha256=th(row['generated_text']) if isinstance(row.get('generated_text'),str) else None,generated_token_ids_sha256=jh(row['generated_token_ids']) if isinstance(row.get('generated_token_ids'),list) else None)
  if row.get('finish_reason')!='EOS' or row.get('stopped_on_eos') is not True:problems.append('eos_incomplete')
 for k,v in actual.items():
  if v!=expected[k]:problems.append(k)
 return problems
class InputCalibrationMismatch(RuntimeError):pass

def execute_stages(calls,expected,generate_one,record_gate):
 """generate_one is the only scientific call path; no retry, one ordered traversal."""
 if len(calls)!=384 or len({c['call_id'] for c in calls})!=384 or [c['sequence'] for c in calls]!=list(range(1,385)):raise ValueError('Exact 384 unique ordered calls required')
 if [c['stage'] for c in calls]!=['CALIBRATION']*24+['SWAP']*360:raise ValueError('Stage order')
 if [e['call_id'] for e in expected]!=[c['call_id'] for c in calls[:24]]:raise ValueError('Calibration set/order')
 checked=[];attempted=set();passed=False;failed_reason=None;produced=[]
 try:
  for i,call in enumerate(calls):
   if i==24:
    passed=len(checked)==24 and all(x['pass'] for x in checked)
    if not passed:break
   if call['call_id'] in attempted or len(attempted)>=384:raise RuntimeError('No retry / hard call cap')
   attempted.add(call['call_id'])
   exp=expected[i] if i<24 else None
   row=generate_one(call,exp)
   if row is None:raise RuntimeError('Missing completed output')
   produced.append(row)
   if exp:
    input_problems=identity(row,exp,output=False)
    if input_problems:raise InputCalibrationMismatch(','.join(input_problems))
    problems=identity(row,exp);checked.append(dict(call_id=call['call_id'],pass_=not problems,problems=problems));checked[-1]['pass']=checked[-1].pop('pass_')
    if problems:failed_reason='CALIBRATION_MISMATCH'
  if len(checked)==24 and all(x['pass'] for x in checked):passed=True
 except BaseException as e:
  failed_reason=type(e).__name__+': '+str(e);raise
 finally:
  complete_ids={r['call_id'] for r in produced}
  record_gate(dict(status='PASS' if passed else 'FAILED',calibration_passed=passed,checks=checked,reason=failed_reason,completed_outputs=len(produced),swap_outputs=sum(c['stage']=='SWAP' and c['call_id'] in complete_ids for c in calls),not_run_swap=[dict(call_id=c['call_id'],status='NOT_RUN_CALIBRATION_FAILED' if not passed else 'NOT_RUN_TECHNICAL_STOP') for c in calls[24:] if c['call_id'] not in attempted],incomplete_control_attempts=sorted(attempted-complete_ids)))
 return produced,passed
