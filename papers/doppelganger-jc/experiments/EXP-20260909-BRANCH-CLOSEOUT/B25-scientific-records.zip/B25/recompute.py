"""Recompute B25 only after actual raw, calibration, and frozen formal files exist.

Python 3 standard library only. No model calls or fabricated completion states.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
from calibration_gate import identity


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw', type=Path, required=True)
    parser.add_argument('--calibration', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    frozen = root / 'analysis-v1' / 'formal-v1'
    if not args.raw.is_file() or not args.calibration.is_file() or not list(frozen.glob('*.json')):
        raise SystemExit('Actual raw, calibration control, and frozen formal files are required; preparation-only data cannot be scored as a completed run.')
    raw_path = args.raw.resolve()
    calibration_path = args.calibration.resolve()
    payload = json.loads(raw_path.read_text())
    calibration = json.loads(calibration_path.read_text())
    expected = json.loads((root / 'CALIBRATION-EXPECTED-HASHES.json').read_text())['checks']
    actual = {r['call_id']: r for r in payload['rows']}
    calibration_checks = []
    for check in expected:
        row = actual.get(check['call_id'])
        problems = identity(row, check) if row is not None else ['NOT_COMPLETED']
        calibration_checks.append({'call_id': check['call_id'],
                                   'completed': row is not None,
                                   'pass': not problems, 'problems': problems})
    calibration_passed = len(calibration_checks) == 24 and all(c['pass'] for c in calibration_checks)
    if calibration_passed != (calibration.get('calibration_passed') is True):
        raise SystemExit('Actual calibration identity checks disagree with the preserved control result; do not substitute a new gate result or rescore silently.')
    args.output.mkdir(parents=True, exist_ok=False)
    output = args.output.resolve() / 'formal-v1'
    subprocess.run(
        [sys.executable, str(root / 'analyze_b25.py'), str(raw_path),
         str(calibration_path), str(output)],
        cwd=root, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
        check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )
    expected_files = {p.name for p in frozen.glob('*.json')}
    actual_files = {p.name for p in output.glob('*.json')}
    comparisons = []
    for name in sorted(expected_files | actual_files):
        before = (frozen / name).read_bytes() if name in expected_files else None
        after = (output / name).read_bytes() if name in actual_files else None
        comparisons.append({
            'file': name,
            'frozen_sha256': sha(before) if before is not None else None,
            'recomputed_sha256': sha(after) if after is not None else None,
            'byte_identical': before is not None and before == after,
            'json_equal': before is not None and after is not None
                          and json.loads(before) == json.loads(after),
        })
    passed = all(c['byte_identical'] for c in comparisons)
    report = {
        'identity': 'PUBLIC_ONLY_B25_FROZEN_SCORE_RECOMPUTATION',
        'status': 'PASS' if passed else 'FAIL',
        'formal_json_files': len(comparisons),
        'all_files_byte_identical': passed,
        'all_files_json_equal': all(c['json_equal'] for c in comparisons),
        'actual_new_output_rows': len(payload['rows']),
        'actual_new_forwards': sum(r['row_forward_n'] for r in payload['rows']),
        'cached_B24_rows_not_new_outputs': 360,
        'calibration_passed_from_actual_completed_rows': calibration_passed,
        'calibration_report_agrees_with_actual_identities': True,
        'calibration_checks': calibration_checks,
        'primary': json.loads((output / 'PRIMARY.AI.json').read_text()),
        'model_calls': 0,
        'human_gold_validation_performed': False,
        'scope': 'Reproduce preserved actual calibration identity and frozen descriptive scores, including all real missing/unknown/not-estimable states; not a new experiment or verification of same-process execution.',
        'files': comparisons,
    }
    (args.output / 'RECOMPUTATION-VERIFICATION.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in
                      ['status', 'formal_json_files', 'all_files_byte_identical',
                       'actual_new_output_rows', 'actual_new_forwards', 'primary', 'model_calls']}))
    if not passed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
