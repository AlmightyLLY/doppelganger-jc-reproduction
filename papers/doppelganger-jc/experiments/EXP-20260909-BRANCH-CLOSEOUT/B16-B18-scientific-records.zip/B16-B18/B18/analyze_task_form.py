"""Frozen B18 all-row analysis; no result-dependent parser changes or exclusions."""
from pathlib import Path
import json,sys,itertools
from collections import Counter
from score_task_form import score,derive
def counts(rows,key):
    cc=Counter(r['score']['labels'][key] for r in rows)
    return {'n':len(rows),**{k:cc[k] for k in ['C','W','U']}}
def contrast(pp,ix,key='participant'):
    a=[ix[p['challenge_record_id']] for p in pp];b=[ix[p['control_record_id']] for p in pp]
    ca,cb=counts(a,key),counts(b,key);n=len(pp)
    assert n>0
    return dict(n=n,challenge=ca,control=cb,W_difference=(ca['W']-cb['W'])/n,
        lower=(ca['W']-cb['W']-cb['U'])/n,upper=(ca['W']+ca['U']-cb['W'])/n,
        C_to_W=sum(x['score']['labels'][key]=='W' and y['score']['labels'][key]=='C' for x,y in zip(a,b)),
        C_to_U=sum(x['score']['labels'][key]=='U' and y['score']['labels'][key]=='C' for x,y in zip(a,b)),
        W_to_C=sum(x['score']['labels'][key]=='C' and y['score']['labels'][key]=='W' for x,y in zip(a,b)),
        U_to_C=sum(x['score']['labels'][key]=='C' and y['score']['labels'][key]=='U' for x,y in zip(a,b)))
def analyze(root,rawfile,out,synthetic=False):
    load=lambda n:json.loads((root/n).read_text())
    calls=load('CALL-PLAN.json')['A'];refs={r['call_id']:r for r in load('SCORING-REFERENCE.json')}
    raw=json.loads(rawfile.read_text());raw=raw['rows'] if isinstance(raw,dict) else raw
    assert len(raw)==len({r['call_id'] for r in raw})==512
    rawix={r['call_id']:r for r in raw};assert set(rawix)=={c['call_id'] for c in calls}
    scored=[]
    for c in calls:
        r=rawix[c['call_id']]
        assert r['messages']==c['messages'] and r['model']==c['model']
        scored.append(c|dict(raw=r,reference=refs[c['call_id']],score=score(r['generated_text'],c,refs[c['call_id']])))
    sx={r['call_id']:r for r in scored};records=[];dx={r['record_id']:r for r in load('DERIVED-PLAN.json')}
    for r in load('RECORD-PLAN.json'):
        if r['mode']=='JOINT':
            source=sx[r['call_ids'][0]];ss=source['score'];values={'occurred':ss['occurred_asserted'],'actor':ss['decoded_names']['role_a'],'undergoer':ss['decoded_names']['role_b']}
        else:
            d=dx[r['record_id']];parts={k:sx[v]['score'] for k,v in d['components'].items()};ss=derive(parts)
            values={'occurred':parts['QA_OCCURRED']['value'],'actor':parts['QA_ACTOR']['value'],'undergoer':parts['QA_UNDERGOER']['value']}
        records.append(r|dict(score=ss,parsed_or_derived_values=values,raw_call_ids=r['call_ids'],
            actual_forward_n=sum(sx[c]['raw'].get('row_forward_n',0) for c in r['call_ids']),
            derived_record=r['mode']=='QA_DERIVED',independent_human_gold=0))
    ix={r['record_id']:r for r in records};pairs=load('PAIRED-PLAN.json');profiles=[];contrasts=[];markers=[];allpairs=[]
    for model,lang,mode in itertools.product(['qwen','llama'],['JA','ZH'],['JOINT','QA_DERIVED']):
        rr=[r for r in records if r['model']==model and r['language']==lang and r['mode']==mode]
        for cond in ['SINGLE','DISJOINT','SHARED_SAME','SHARED_OPPOSITE']:
            sub=[r for r in rr if r['condition']==cond];assert len(sub)==8
            profiles.append(dict(model=model,language=lang,mode=mode,condition=cond,**{k:counts(sub,k) for k in ['participant','occurrence','record','role_a','role_b']},format=dict(Counter(r['score']['format_compliance'] for r in sub))))
        single=counts([r for r in rr if r['condition']=='SINGLE'],'participant')
        marker=dict(model=model,language=lang,mode=mode,single=single,single_floor_pass=single['C']>=7,contrasts={})
        for typ in ['OPPOSITE_VS_DISJOINT','OPPOSITE_VS_SHARED_SAME']:
            pp=[p for p in pairs if p['model']==model and p['language']==lang and p.get('mode')==mode and p['pair_type']==typ]
            allc=contrast(pp,ix);families={f:contrast([p for p in pp if p['lexical_family']==f],ix) for f in sorted({p['lexical_family'] for p in pp})}
            contrasts.append(dict(model=model,language=lang,mode=mode,pair_type=typ,all=allc,by_family=families,by_polarity={f:contrast([p for p in pp if p['fact']==f],ix) for f in ['YES','NO']}))
            marker['contrasts'][typ]=dict(lower_positive=allc['lower']>0,positive_family_n=sum(d['W_difference']>0 for d in families.values()))
        marker['exploratory_pattern']=marker['single_floor_pass'] and all(c['lower_positive'] and c['positive_family_n']>=3 for c in marker['contrasts'].values());markers.append(marker)
    for p in pairs:
        a,b=ix[p['control_record_id']],ix[p['challenge_record_id']];aa,bb=a['score']['labels'],b['score']['labels']
        harms=[k for k in ['role_a','role_b','occurrence'] if aa[k]=='C' and bb[k] in ['W','U']]
        allpairs.append(p|dict(transitions={k:aa[k]+'->'+bb[k] for k in ['role_a','role_b','participant','occurrence','record']},new_component_harms=harms,
            added_role_harm_on_existing_occurrence_W=aa['occurrence']=='W' and any(k in harms for k in ['role_a','role_b']),
            added_component_harm_record_W_to_W=aa['record']==bb['record']=='W' and bool(harms)))
    cross=[]
    for model,lang in itertools.product(['qwen','llama'],['JA','ZH']):
        mm=[m for m in markers if m['model']==model and m['language']==lang]
        cross.append(dict(model=model,language=lang,both_modes_pass=all(m['exploratory_pattern'] for m in mm),joint_replication_pass=next(m['exploratory_pattern'] for m in mm if m['mode']=='JOINT'),identity='LOCAL_AUTHOR_EXPLORATORY_CROSS_TASK_SIGNAL_NOT_INDEPENDENT_CONFIRMATION'))
    within_mode=[]
    for model,lang,mode,cond in itertools.product(['qwen','llama'],['JA','ZH'],['JOINT','QA_DERIVED'],['DISJOINT','SHARED_SAME','SHARED_OPPOSITE']):
        pp=[p for p in pairs if p['pair_type']=='CONTEXT_VS_SINGLE' and p['model']==model and p['language']==lang and p['mode']==mode and p['condition']==cond]
        within_mode.append(dict(model=model,language=lang,mode=mode,condition=cond,**{k:contrast(pp,ix,k) for k in ['participant','occurrence','record','role_a','role_b']}))
    cross_mode=[]
    for model,lang,cond in itertools.product(['qwen','llama'],['JA','ZH'],['SINGLE','DISJOINT','SHARED_SAME','SHARED_OPPOSITE']):
        pp=[p for p in pairs if p['pair_type']=='QA_VS_JOINT' and p['model']==model and p['language']==lang and p['condition']==cond]
        cross_mode.append(dict(model=model,language=lang,condition=cond,**{k:contrast(pp,ix,k) for k in ['participant','occurrence','record','role_a','role_b']}))
    summary=dict(experiment_id='EXP-20260908-B18',actual_model_outputs=0 if synthetic else 512,synthetic_response_rows=512 if synthetic else 0,
        scored_records=256,qa_derived_records=128,actual_forwards=sum(r.get('row_forward_n',0) for r in raw),profiles=profiles,primary_contrasts=contrasts,mode_markers=markers,cross_task_markers=cross,within_mode_context_comparisons=within_mode,cross_mode_comparisons=cross_mode,
        independent_human_gold=0,identification_bounds_not_confidence_intervals=True,old_B16_B17_markers_unchanged=True,automatic_B19=False,cost_warning='QA combines 3 independent calls versus 1 JOINT; bundled task/instruction/output-arity change')
    out.mkdir(parents=True,exist_ok=False)
    for name,obj in [('ACTUAL-SCORED-ROWS.AI.json',scored),('RECORDS.AI.json',records),('PAIRS.AI.json',allpairs),('COMPONENT-HARMS.AI.json',[p for p in allpairs if p['new_component_harms']]),('SUMMARY.json',summary)]:
        (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
    return summary
if __name__=='__main__':
    result=analyze(Path(__file__).resolve().parent,Path(sys.argv[1]),Path(sys.argv[2]));print(json.dumps({'outputs':result['actual_model_outputs'],'cross_task_markers':result['cross_task_markers']}))
