"""Prospective B18 grammar. No substring extraction or reference-assisted parsing."""
from score_b09 import score as score_joint,combine
QUOTES={'"':'"',"'":"'",'“':'”','「':'」'}
PERIODS=('.', '。')

def parse_qa(text):
    raw=text.strip()
    token=raw
    wrapper='NONE'
    # Exactly one operation. Quoted-with-period or nested wrappers are not unwrapped twice.
    if len(raw)>=2 and raw[0] in QUOTES and raw[-1]==QUOTES[raw[0]]:
        token=raw[1:-1];wrapper='ONE_QUOTE_PAIR'
    elif raw.endswith(PERIODS):
        token=raw[:-1];wrapper='ONE_FINAL_PERIOD'
    return {'trimmed':raw,'token':token,'wrapper':wrapper}

def score(text,call,ref):
    if call['task']=='JOINT':
        return score_joint(text,call,ref)
    parsed=parse_qa(text);token=parsed['token'];names=list(call['entity_map'].values())
    if call['task'] in ['QA_ACTOR','QA_UNDERGOER']:
        component='role_a' if call['task']=='QA_ACTOR' else 'role_b'
        value=token if token in names else None
        label='C' if value==ref[component] else 'W' if value is not None else 'U'
        reason='LISTED_NAME' if value is not None else 'UNKNOWN_OR_NULL' if token.lower() in ['unknown','null'] else 'OUTSIDE_FROZEN_GRAMMAR'
        canonical=names+['UNKNOWN'];grammar_ok=value is not None or token.lower() in ['unknown','null']
    else:
        assert call['task']=='QA_OCCURRED'
        component='occurrence';value=token if token in ['YES','NO','UNKNOWN'] else None
        label='C' if value==ref['occurred'] else 'W' if value in ['YES','NO'] else 'U'
        reason='OCCURRENCE_LABEL' if value is not None else 'OUTSIDE_FROZEN_GRAMMAR'
        canonical=['YES','NO','UNKNOWN'];grammar_ok=value is not None
    return {'component':component,'label':label,'value':value,'reason':reason,'parse':parsed,
        'grammar_compliance':'PASS' if grammar_ok else 'FAIL',
        'format_compliance':'PASS' if parsed['trimmed'] in canonical else 'FAIL',
        'format_definition':'Strict requested bare name or uppercase label after outer whitespace; allowed parser wrappers retained separately',
        'language_status':'CANONICAL_SCHEMA_VALUES' if parsed['trimmed'] in canonical else 'REQUIRES_FULL_RESPONSE_LANGUAGE_REVIEW',
        'identity':'AI_SCORING_NOT_HUMAN_GOLD','full_response_read':False}

def derive(scores):
    assert set(scores)=={'QA_ACTOR','QA_UNDERGOER','QA_OCCURRED'}
    labels={scores[k]['component']:scores[k]['label'] for k in scores}
    labels['participant']=combine(labels['role_a'],labels['role_b'])
    labels['record']=combine(labels['participant'],labels['occurrence'])
    return {'labels':labels,'format_compliance':'PASS' if all(v['format_compliance']=='PASS' for v in scores.values()) else 'FAIL',
        'identity':'DETERMINISTIC_DERIVED_RECORD_NOT_NEW_MODEL_OUTPUT','new_calls':0,'new_forwards':0}
