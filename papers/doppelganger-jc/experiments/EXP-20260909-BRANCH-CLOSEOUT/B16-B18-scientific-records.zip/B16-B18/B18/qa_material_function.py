"""Exact frozen B18 QA function; no top-level authoring."""
from joint_prompt import NAMES
def qa_prompt(lang, source, verb, task):
    if lang == 'JA':
        head = '以下は架空の人物についての記録です。R1とR2は別の時点の出来事です。対象はR1だけです。\n人物一覧：' + '、'.join(NAMES) + '\n記録：\n' + source + '\n'
        if task == 'QA_OCCURRED':
            return head + 'R1でその出来事が起きたと明記されていますか。起きたと明記されていればYES、起きなかったと明記されていればNO、判断できなければUNKNOWNです。説明を付けず、YES、NO、UNKNOWNのいずれか一つだけを返してください。'
        role = f'{verb}する側' if task == 'QA_ACTOR' else f'{verb}される側'
        return head + f'R1の文で指定された{role}の人物は誰ですか。' + f'行為が起きなかった場合でも、R1の文で指定された{role}を答えてください。実際に行為が起きたとは推測しないでください。人物一覧の名前を一つだけ返し、特定できない場合はUNKNOWNを返してください。説明や他の名前を付けないでください。'
    head = '以下是关于虚构人物的记录。R1与R2指不同时间的事件。只回答R1。\n人物名单：' + '、'.join(NAMES) + '\n记录：\n' + source + '\n'
    if task == 'QA_OCCURRED':
        return head + 'R1是否明确说该事件发生？R1明确说事件发生填YES，明确说未发生填NO，无法确定填UNKNOWN。只返回YES、NO、UNKNOWN中的一个标签，不附解释。'
    role = f'实施{verb}的一方' if task == 'QA_ACTOR' else f'被{verb}的一方'
    return head + f'R1句中指定的{role}是谁？即使行为没有发生，也按R1句中指定的{role}回答，不据此推断行动实际发生。只返回一个人物名单中的姓名，无法确定时返回UNKNOWN，不附解释或其他姓名。'
