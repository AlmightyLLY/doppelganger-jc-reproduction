"""Recompute B16-B18 frozen descriptive scores from public records.

Python 3 standard library only; no model calls. Output must be a new directory.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).resolve().parent
    scripts = {'B16': 'analyze_competition.py', 'B17': 'analyze_competition.py',
               'B18': 'analyze_task_form.py'}
    results = []
    for batch, name in scripts.items():
        batch_root = root / batch
        output = args.output / batch
        subprocess.run(
            [sys.executable, str(batch_root / name),
             str(batch_root / 'analysis-v1' / 'RAW-RESPONSES.json'), str(output)],
            cwd=batch_root, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
            check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        )
        frozen = batch_root / 'analysis-v1' / 'formal-v1'
        expected = {p.name for p in frozen.glob('*.json')}
        actual = {p.name for p in output.glob('*.json')}
        for filename in sorted(expected | actual):
            before = (frozen / filename).read_bytes() if filename in expected else None
            after = (output / filename).read_bytes() if filename in actual else None
            results.append({
                'batch': batch, 'file': filename,
                'frozen_sha256': sha(before) if before is not None else None,
                'recomputed_sha256': sha(after) if after is not None else None,
                'byte_identical': before is not None and before == after,
                'json_equal': before is not None and after is not None
                              and json.loads(before) == json.loads(after),
            })
    passed = all(row['byte_identical'] for row in results)
    report = {
        'identity': 'PUBLIC_ONLY_FROZEN_SCORE_RECOMPUTATION',
        'status': 'PASS' if passed else 'FAIL',
        'formal_json_files': len(results),
        'all_files_byte_identical': passed,
        'all_files_json_equal': all(row['json_equal'] for row in results),
        'model_calls': 0,
        'human_gold_validation_performed': False,
        'scope': 'Fresh recomputation from this repackaged public dataset after configuration redaction; unchanged score functions and all preserved raw answers, with no model generation or independent semantic validation.',
        'files': results,
    }
    (args.output / 'RECOMPUTATION-VERIFICATION.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in
                      ['status', 'formal_json_files', 'all_files_byte_identical', 'model_calls']}))
    if not passed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
