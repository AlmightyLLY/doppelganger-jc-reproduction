"""Frozen B16/B17 analysis; raw input is {rows:[{call_id,generated_text,...}]}.
No outcome-dependent exclusions, learned thresholds, or independent-gold claims.
"""
from pathlib import Path
import json,sys,itertools
from collections import Counter
from score_b09 import score

def counts(rows,key):
    c=Counter(r['score']['labels'][key] for r in rows)
    return {'n':len(rows),**{x:c[x] for x in ['C','W','U']}}

def contrast(pairs,ix,key='participant'):
    a=[ix[p['challenge_call_id']] for p in pairs];b=[ix[p['control_call_id']] for p in pairs]
    ca,cb=counts(a,key),counts(b,key);n=len(pairs)
    if not n:return {'n':0,'lower':None,'upper':None}
    return {'n':n,'challenge':ca,'control':cb,
      'W_difference':(ca['W']-cb['W'])/n,
      'lower':(ca['W']-cb['W']-cb['U'])/n,
      'upper':(ca['W']+ca['U']-cb['W'])/n,
      'C_to_W':sum(x['score']['labels'][key]=='W' and y['score']['labels'][key]=='C' for x,y in zip(a,b)),
      'C_to_U':sum(x['score']['labels'][key]=='U' and y['score']['labels'][key]=='C' for x,y in zip(a,b)),
      'WU_to_C':sum(x['score']['labels'][key]=='C' and y['score']['labels'][key]!='C' for x,y in zip(a,b))}

def analyze(root,rawfile,out):
    load=lambda n:json.loads((root/n).read_text())
    calls=load('CALL-PLAN.json')['A'];refs={r['call_id']:r for r in load('SCORING-REFERENCE.json')}
    raw=json.loads(rawfile.read_text());raw=raw['rows'] if isinstance(raw,dict) else raw
    assert len(raw)==len({r['call_id'] for r in raw})
    rawix={r['call_id']:r for r in raw};assert set(rawix)=={c['call_id'] for c in calls},'Partial batch: do not silently exclude missing calls'
    scored=[]
    for c in calls:
        rr=rawix[c['call_id']]
        if 'messages' in rr:assert rr['messages']==c['messages']
        if 'model' in rr and isinstance(rr['model'],str):assert rr['model']==c['model']
        s=score(rr['generated_text'],c,refs[c['call_id']]);ref=refs[c['call_id']]
        swap=(s['decoded_names']['role_a']==ref['role_b'] and s['decoded_names']['role_b']==ref['role_a'])
        scored.append({**c,'raw':rr,'reference':ref,'score':s,'exact_role_swap':swap})
    ix={r['call_id']:r for r in scored};pairs=load('PAIRED-PLAN.json');spec=load('RUN-SPEC.json')
    profiles=[];contrasts=[];markers=[];harms=[]
    for model,lang in itertools.product(['qwen','llama'],['JA','ZH']):
        rr=[r for r in scored if r['model']==model and r['language']==lang]
        for cond,pos in [('SINGLE','NONE')]+list(itertools.product(['DISJOINT','SHARED_SAME','SHARED_OPPOSITE'],['FIRST','LAST'])):
            sub=[r for r in rr if r['condition']==cond and r['position']==pos]
            profiles.append({'model':model,'language':lang,'condition':cond,'position':pos,
                **{k:counts(sub,k) for k in ['participant','occurrence','record','role_a','role_b']},
                'exact_role_swaps':sum(r['exact_role_swap'] for r in sub),
                'format':dict(Counter(r['score']['format_compliance'] for r in sub))})
        single=[r for r in rr if r['condition']=='SINGLE']
        singleix={r['source_id']:r for r in single};base=counts(single,'participant')
        marker={'model':model,'language':lang,'single':base,'floor_pass':base['C']>=spec['signal_floor_single_C'],'contrasts':{}}
        for typ in ['OPPOSITE_VS_DISJOINT','OPPOSITE_VS_SHARED_SAME']:
            pp=[p for p in pairs if p['model']==model and p['language']==lang and p['pair_type']==typ]
            d=contrast(pp,ix);family={f:contrast([p for p in pp if p['lexical_family']==f],ix) for f in sorted({p['lexical_family'] for p in pp})}
            positions={pos:contrast([p for p in pp if p['position']==pos],ix) for pos in ['FIRST','LAST']}
            byfact={fact:contrast([p for p in pp if p['fact']==fact],ix) for fact in ['YES','NO']}
            conditioned=[p for p in pp if singleix[p['source_id']]['score']['labels']['participant']=='C']
            row={'model':model,'language':lang,'pair_type':typ,'all':d,'lexical_clusters':family,
                'positions':positions,'fact':byfact,'single_correct_sensitivity':contrast(conditioned,ix)}
            contrasts.append(row)
            marker['contrasts'][typ]={'bound_at_least_005':d['lower']>=spec['signal_min_contrast_lower_bound'],
                'positive_family_n':sum(v['W_difference']>0 for v in family.values()),
                'both_positions_positive':all(v['W_difference']>0 for v in positions.values())}
        marker['exploratory_pattern']=marker['floor_pass'] and all(v['bound_at_least_005'] and v['positive_family_n']>=3 and v['both_positions_positive'] for v in marker['contrasts'].values())
        markers.append(marker)
    for p in pairs:
        a,b=ix[p['control_call_id']],ix[p['challenge_call_id']]
        damaged=[k for k in ['occurrence','role_a','role_b'] if a['score']['labels'][k]=='C' and b['score']['labels'][k] in ['W','U']]
        if damaged:harms.append({**p,'damaged_components':damaged,'old_record':a['score']['labels']['record'],'new_record':b['score']['labels']['record']})
    out.mkdir(parents=True,exist_ok=False)
    result={'experiment_id':spec['experiment_id'],'new_outputs':len(raw),'rows_by_model':dict(Counter(r['model'] for r in calls)),
        'overall':{k:counts(scored,k) for k in ['participant','occurrence','record']},
        'condition_profiles':profiles,'primary_contrasts':contrasts,'exploratory_markers':markers,
        'independent_human_gold':0,'confirmatory_claim':False,
        'precision_limit':'4 lexical clusters; matched U bounds are identification bounds, not confidence intervals; no pooled independent-position significance test',
        'frozen_all_rows_included':True,'no_automatic_B18':True}
    for name,val in [('SCORED-ROWS.AI.json',scored),('SUMMARY.json',result),('COMPONENT-HARMS.AI.json',harms)]:
        (out/name).write_text(json.dumps(val,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'experiment_id':spec['experiment_id'],'outputs':len(raw),'overall':result['overall'],'markers':markers},ensure_ascii=False))

if __name__=='__main__':analyze(Path(__file__).resolve().parent,Path(sys.argv[1]),Path(sys.argv[2]))
