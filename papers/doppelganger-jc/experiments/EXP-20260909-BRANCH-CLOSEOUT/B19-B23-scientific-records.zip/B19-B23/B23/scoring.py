"""Frozen B23 scoring. No inferred repair, model judging, or missing-run U labels."""
from collections import Counter
from score_b09 import candidates,ObjectPairs,combine
ROLES=['role_a','role_b','participant','participant_set']
def categories(decoded,call):
 a,b=decoded['role_a'],decoded['role_b'];matches=[]
 if a is None or b is None:return dict(matches=[],status_category='UNRESOLVED',pair=[a,b])
 target=call['target_pair'];dist=call.get('distractor_pair');pairs={'TARGET':target,'TARGET_REVERSED':target[::-1]}
 if dist is not None:pairs.update(DISTRACTOR=dist,DISTRACTOR_REVERSED=dist[::-1])
 matches=[k for k,v in pairs.items() if [a,b]==v]
 return dict(matches=matches,status_category='MATCHED' if matches else 'DUPLICATE_PERSON' if a==b else 'OTHER_COMPLETE',pair=[a,b],ambiguous_named_matches=len(matches)>1,interpretation='OUTPUT_DESCRIPTION_NOT_INTERNAL_SELECTION')
def participant_set(decoded,ref):
 a,b=decoded['role_a'],decoded['role_b'];target=[ref['role_a'],ref['role_b']]
 if a is None or b is None:return 'W' if any(x is not None and x not in target for x in [a,b]) else 'U'
 return 'C' if Counter([a,b])==Counter(target) else 'W'
def role_score(text,call):
 spans=candidates(text);unique=len(spans)==1 and isinstance(spans[0][2],ObjectPairs);obj=spans[0][2] if unique else [];keys=[k for k,v in obj];expected=['actor','undergoer'];vals={};reasons={};decoded={};labels={}
 for comp,k in zip(['role_a','role_b'],expected):
  vs=[v for key,v in obj if key==k];v=vs[0] if len(vs)==1 else None;vals[k]=v
  reasons[k]='UNIQUE' if len(vs)==1 else 'DUPLICATE_KEY' if len(vs)>1 else 'MISSING_OR_AMBIGUOUS_OBJECT'
  person=v if isinstance(v,str) and v in call['entity_map'].values() else None
  decoded[comp]=person;labels[comp]='U' if person is None else 'C' if person==call['reference'][comp] else 'W'
 labels.update(participant=combine(labels['role_a'],labels['role_b']),participant_set=participant_set(decoded,call['reference']),occurrence='N/A_NOT_REQUESTED',record='N/A_NOT_REQUESTED')
 direct=unique and text.strip()==text[spans[0][0]:spans[0][1]];fmt=direct and sorted(keys)==sorted(expected) and all(v is None or isinstance(v,str) for v in vals.values())
 noncanonical=[k for comp,k in zip(['role_a','role_b'],expected) if vals[k] is not None and decoded[comp] is None]
 return dict(labels=labels,decoded_names=decoded,categories=categories(decoded,call),raw_fields=vals,field_identity_reasons=reasons,format_compliance='PASS' if fmt else 'FAIL',language_status='CANONICAL_SCHEMA_VALUES' if fmt and not noncanonical else 'REQUIRES_FULL_RESPONSE_LANGUAGE_REVIEW',duplicate_keys=[k for k,n in Counter(keys).items() if n>1],extra_keys=[k for k in keys if k not in expected],raw_object_pairs=obj,unique_readable_object=unique,identity='AI_SCORING_NOT_HUMAN_GOLD',full_response_read=False)
def choice_score(text,correct):
 assert correct in ['A','B'];letter=text.strip();valid=letter in ['A','B']
 return dict(label=('C' if letter==correct else 'W') if valid else 'U',letter=letter if valid else None,format_compliance='PASS' if valid else 'FAIL',reason='EXACT_LETTER' if valid else 'U_PARSE',raw=text)
def choice_pair(a,b):
 if a is None or b is None:return dict(status='NOT_RUN' if a is None and b is None else 'INCOMPLETE_TECHNICAL',label=None,reason=None,fixed_letter=None)
 x,y=a['label'],b['label']
 if 'U' in [x,y]:label,reason='U','U_PARSE'
 elif x==y:label,reason=x,'STABLE_CORRECT' if x=='C' else 'STABLE_REVERSED'
 else:label,reason='U','U_ORDER_SENSITIVE'
 return dict(status='COMPLETE',label=label,reason=reason,fixed_letter=('FIXED_'+a['letter']) if a['letter']==b['letter'] and a['letter'] in ['A','B'] else None)
def counts(rows):
 c=Counter(r['label'] for r in rows);return dict(n=len(rows),C=c['C'],W=c['W'],U=c['U'],not_scored=sum(r['label'] is None for r in rows))
def delta(challenge,control):
 assert len(challenge)==len(control)>0;a,b=counts(challenge),counts(control);n=len(challenge)
 if a['not_scored'] or b['not_scored']:return dict(status='INCOMPLETE_TECHNICAL',challenge=a,control=b,n=n,Delta=None,lower=None,upper=None)
 return dict(status='COMPLETE',challenge=a,control=b,n=n,Delta=(a['W']-b['W'])/n,lower=(a['W']-b['W']-b['U'])/n,upper=(a['W']+a['U']-b['W'])/n)
def tag(single,overall,families,lists):
 assert len(single)==8 and len(families)==4 and len(lists)==2
 cap=counts(single);complete=cap['not_scored']==0 and all(x['status']=='COMPLETE' for x in [overall,*families.values(),*lists.values()])
 return dict(status='COMPLETE' if complete else 'INCOMPLETE_TECHNICAL',single=cap,capability=(cap['C']>=7) if cap['not_scored']==0 else None,T=(cap['C']>=7 and overall['lower']>0 and sum(x['lower']>0 for x in families.values())>=3 and all(x['lower']>0 for x in lists.values())) if complete else None)
def transition(a,b):return None if a is None or b is None else a+'->'+b
