"""B23 prospective analysis, accepts actual raw records only; no inference."""
from pathlib import Path
from collections import Counter
import json,sys,copy
from scoring import role_score,choice_score,choice_pair,participant_set,counts,delta,tag,transition,ROLES
P=Path(__file__).resolve().parent
def analyze(raw,started_call_ids=None):
 plan=json.loads((P/'CALL-PLAN.json').read_text());sources=json.loads((P/'SOURCE-SELECTION.json').read_text())['rows'];source={r['B21_call_id']:r for r in sources};calls=plan['calls'];lookup={c['call_id']:c for c in calls}
 assert len(raw)==len({r['call_id'] for r in raw}) and all(r['call_id'] in lookup for r in raw)
 actual={r['call_id']:r for r in raw};answers=[];scored={};started=set(started_call_ids or actual)
 assert started<=set(lookup) and set(actual)<=started
 for c in calls:
  r=actual.get(c['call_id']);sc=None
  if r is not None:
   assert r['messages']==c['messages'] and r['prompt_sha256']==c['prompt_sha256'] and isinstance(r['generated_text'],str)
   sc=role_score(r['generated_text'],c) if c['task']=='ROLE_ONLY' else choice_score(r['generated_text'],c['correct_option'])
  scored[c['call_id']]=sc;answers.append(dict(plan=c,status='COMPLETE' if r else 'STARTED_UNKNOWN' if c['call_id'] in started else 'NOT_RUN',actual=r,score=sc))
 records=[];paired=[]
 for g in plan['groups']:
  s=source[g['B21_call_id']];meta={k:s[k] for k in ['B21_call_id','base_id','lexical_family','name_set','fact','condition','distractor_fact']}
  old=copy.deepcopy(s['natural_score']);old['labels']['participant_set']=participant_set(old['decoded_names'],s['reference'])
  records.append(dict(**meta,task='JOINT',status='REUSED_FROZEN',label=old['labels']['participant'],score=old,raw=s['natural_raw'],source=s))
  role=scored[g['ROLE_ONLY']];records.append(dict(**meta,task='ROLE_ONLY',status='COMPLETE' if role else 'STARTED_UNKNOWN' if g['ROLE_ONLY'] in started else 'NOT_RUN',label=role['labels']['participant'] if role else None,score=role,call_ids=[g['ROLE_ONLY']]))
  pair=choice_pair(scored[g['CHOICE_A']],scored[g['CHOICE_B']])
  if pair['status']=='NOT_RUN' and any(g[k] in started for k in ['CHOICE_A','CHOICE_B']):pair['status']='INCOMPLETE_TECHNICAL'
  records.append(dict(**meta,task='CHOICE',**pair,call_ids=[g['CHOICE_A'],g['CHOICE_B']]))
  paired.append(dict(**meta,JOINT_role=old['labels']['participant'],ROLE_ONLY_role=role['labels']['participant'] if role else None,CHOICE=pair,role_task_switch_transitions={k:transition(old['labels'][k],role['labels'][k] if role else None) for k in ROLES},interpretation='ROLE_TASK_SWITCH_DESCRIPTION_CHOICE_COMPARISON_NOT_REPAIR_RATE'))
 capabilities=[];contrasts=[];tags=[];cells=[];relation_diffs=[]
 for task in ['JOINT','ROLE_ONLY','CHOICE']:
  for fact in ['YES','NO']:
   rr=[r for r in records if r['task']==task and r['fact']==fact];single=[r for r in rr if r['condition']=='SINGLE'];assert len(single)==8
   capabilities.append(dict(task=task,fact=fact,**counts(single),threshold=7,passed=None if counts(single)['not_scored'] else counts(single)['C']>=7))
   for cond in ['SINGLE','DISJOINT','CROSS_ACTOR']:
    for dist in (['NONE'] if cond=='SINGLE' else ['YES','NO']):
     subset=[r for r in rr if r['condition']==cond and r['distractor_fact']==dist]
     for facet,values in [('all',['all']),('lexical_family',sorted({r['lexical_family'] for r in subset})),('name_set',['N1','N2'])]:
      for val in values:cells.append(dict(task=task,fact=fact,condition=cond,distractor_fact=dist,facet=facet,value=val,**counts([r for r in subset if facet=='all' or r[facet]==val])))
   rel={}
   for cond in ['DISJOINT','CROSS_ACTOR']:
    sub=[r for r in rr if r['condition']==cond]
    def comp(part):return delta([r for r in part if r['distractor_fact']=='YES'],[r for r in part if r['distractor_fact']=='NO'])
    overall=comp(sub);families={v:comp([r for r in sub if r['lexical_family']==v]) for v in sorted({r['lexical_family'] for r in sub})};lists={v:comp([r for r in sub if r['name_set']==v]) for v in ['N1','N2']};rel[cond]=overall
    contrasts.append(dict(task=task,fact=fact,condition=cond,all=overall,families=families,name_sets=lists))
    if cond=='CROSS_ACTOR':tags.append(dict(task=task,fact=fact,primary=task=='CHOICE' and fact=='NO',label_name='T_'+task if fact=='NO' else 'DIAGNOSTIC_'+task+'_YES',**tag(single,overall,families,lists)))
   a,b=rel['CROSS_ACTOR'],rel['DISJOINT'];ok=a['status']==b['status']=='COMPLETE';relation_diffs.append(dict(task=task,fact=fact,CROSS_minus_DISJOINT=a['Delta']-b['Delta'] if ok else None,lower=a['lower']-b['upper'] if ok else None,upper=a['upper']-b['lower'] if ok else None,interpretation='DESCRIPTIVE_CONSERVATIVE_IDENTIFICATION_NOT_CI'))
 harms=[]
 for fact in ['YES','NO']:
  for cond in ['SINGLE','DISJOINT','CROSS_ACTOR']:
   for dist in (['NONE'] if cond=='SINGLE' else ['YES','NO']):
    subset=[p for p in paired if p['fact']==fact and p['condition']==cond and p['distractor_fact']==dist]
    for facet,values in [('all',['all']),('lexical_family',sorted({p['lexical_family'] for p in subset})),('name_set',['N1','N2'])]:
     for val in values:
      group=[p for p in subset if facet=='all' or p[facet]==val]
      for comp in ROLES:
       c=Counter(p['role_task_switch_transitions'][comp] for p in group)
       harms.append(dict(fact=fact,condition=cond,distractor_fact=dist,facet=facet,value=val,component=comp,n=len(group),not_scored=c[None],transitions={x+'->'+y:c[x+'->'+y] for x in ['C','W','U'] for y in ['C','W','U']},interpretation='TASK_SWITCH_NOT_PREFIX_CAUSAL_EFFECT'))
 return dict(answers=answers,records=records,paired=paired,capabilities=capabilities,contrasts=contrasts,tags=tags,cells=cells,role_task_switch_stratified=harms,relation_differences=relation_diffs,choice_order_diagnostics=dict(Counter(str(r.get('reason')) for r in records if r['task']=='CHOICE')),choice_fixed_letter=dict(Counter(str(r.get('fixed_letter')) for r in records if r['task']=='CHOICE')),choice_single_order_counts={order:dict(Counter(scored[c['call_id']]['label'] if scored[c['call_id']] else 'NOT_RUN' for c in calls if c['task']=='CHOICE' and c['correct_option']==order)) for order in ['A','B']},identity='AUTHOR_AI_DEVELOPMENT_NOT_HUMAN_GOLD')
if __name__=='__main__':
 payload=json.loads(Path(sys.argv[1]).read_text());raw=payload['rows'] if isinstance(payload,dict) else payload;started=payload.get('started_call_ids') if isinstance(payload,dict) else None;out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
 for k,v in analyze(raw,started).items():(out/(k.upper()+'.AI.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
