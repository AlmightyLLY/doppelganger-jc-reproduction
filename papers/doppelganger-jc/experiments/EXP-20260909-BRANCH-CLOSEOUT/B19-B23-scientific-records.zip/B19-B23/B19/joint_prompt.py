NAMES=['青木', '森田', '小川', '上田']

def sentence(lang,prefix,actor,patient,verb,fact):
    if lang=='JA': return f'{prefix}、{patient}は{actor}に{verb}'+('されました。' if fact=='YES' else 'されませんでした。')
    return f'{prefix}，{patient}'+(f'被{actor}{verb}了。' if fact=='YES' else f'没有被{actor}{verb}。')

def prompt(lang,source,verb):
    schema='{"occurred":"YES/NO/UNKNOWN","actor":"人名","undergoer":"人名"}'
    if lang=='JA':
        return ('以下は架空の人物についての記録です。R1とR2は別の時点の出来事です。対象はR1だけです。\n'
        +'人物一覧：'+ '、'.join(NAMES)+'\n記録：\n'+source+'\n'
        +f'R1について、actorは{verb}する側、undergoerは{verb}される側の人物です。'
        +'否定文でも、文に指定された両者を答えてください。実際に行為が起きたとは推測しないでください。'
        +'occurredは、R1でその出来事が起きたと明記されていればYES、起きなかったと明記されていればNO、判断できなければUNKNOWNです。'
        +'人物の値には人物一覧の名前だけを使い、特定できない場合はnullにしてください。\n'
        +'説明を付けず、次のキーを持つJSONオブジェクトを一つだけ返してください：'+schema)
    return ('以下是关于虚构人物的记录。R1与R2指不同时间的事件。只回答R1。\n'
        +'人物名单：'+'、'.join(NAMES)+'\n记录：\n'+source+'\n'
        +f'对于R1，actor是实施{verb}的一方，undergoer是被{verb}的一方。'
        +'即使是否定句，也返回句中指定的双方，不据此推断行动实际发生。'
        +'occurred：R1明确说事件发生填YES，明确说未发生填NO，无法确定填UNKNOWN。'
        +'人物值只能使用名单中的姓名，无法确定时填null。\n'
        +'只返回一个具有以下键的JSON对象，不附解释：'+schema)
