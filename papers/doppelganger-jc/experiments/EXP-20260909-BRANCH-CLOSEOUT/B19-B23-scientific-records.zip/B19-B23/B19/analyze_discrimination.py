"""Prospective B19 observable categories and paired selection analysis."""
from pathlib import Path
import json,itertools,sys
from collections import Counter
from score_b09 import score
COMPONENTS=['role_a','role_b','participant','occurrence','record']
def categories(sc,call):
    a,b=sc['decoded_names']['role_a'],sc['decoded_names']['role_b'];matches=[]
    if a is None or b is None:return {'matches':[],'status_category':'UNRESOLVED','ambiguous_named_matches':False,'pair':[a,b],'interpretation':'OUTPUT_DESCRIPTION_NOT_INTERNAL_SELECTION'}
    target=call['target_pair'];dist=call['distractor_pair'];candidates={'TARGET':target,'TARGET_REVERSED':target[::-1]}
    if dist is not None:candidates.update(DISTRACTOR=dist,DISTRACTOR_REVERSED=dist[::-1])
    matches=[name for name,pair in candidates.items() if [a,b]==pair]
    status='MATCHED' if matches else 'DUPLICATE_PERSON' if a==b else 'OTHER_COMPLETE'
    return dict(matches=matches,status_category=status,ambiguous_named_matches=len(matches)>1,pair=[a,b],interpretation='OUTPUT_DESCRIPTION_NOT_INTERNAL_SELECTION')
def counts(rows,key):
    c=Counter(r['score']['labels'][key] for r in rows);return {'n':len(rows),**{k:c[k] for k in ['C','W','U']}}
def category_counts(rows):
    return {'n':len(rows),'set_match_counts':dict(Counter(k for r in rows for k in r['categories']['matches'])),'status_counts':dict(Counter(r['categories']['status_category'] for r in rows)),'ambiguous_named_matches':sum(r['categories']['ambiguous_named_matches'] for r in rows),'warning':'Set matches may overlap and need not sum to n.'}
def compare(control,challenge,key='participant'):
    assert len(control)==len(challenge)>0
    a,b=counts(control,key),counts(challenge,key);n=len(control);trans=Counter(x['score']['labels'][key]+'->'+y['score']['labels'][key] for x,y in zip(control,challenge))
    return {'n':n,'control':a,'challenge':b,'W_difference':(b['W']-a['W'])/n,'C_difference':(b['C']-a['C'])/n,'W_lower':(b['W']-a['W']-a['U'])/n,'W_upper':(b['W']+b['U']-a['W'])/n,'C_lower':(b['C']-a['C']-a['U'])/n,'C_upper':(b['C']+b['U']-a['C'])/n,'transitions':{x+'->'+y:trans[x+'->'+y] for x in ['C','W','U'] for y in ['C','W','U']}}
def paired_detail(a,b):
    aa,bb=a['score']['labels'],b['score']['labels'];harms=[k for k in ['role_a','role_b','occurrence'] if aa[k]=='C' and bb[k] in ['W','U']]
    return dict(transitions={k:aa[k]+'->'+bb[k] for k in COMPONENTS},new_component_harms=harms,added_component_harm_on_original_record_W=aa['record']=='W' and bool(harms),added_role_harm_on_original_occurrence_W=aa['occurrence']=='W' and any(k in harms for k in ['role_a','role_b']))
def analyze(root,rawfile,out,synthetic=False):
    load=lambda n:json.loads((root/n).read_text());calls=load('CALL-PLAN.json')['A'];refs={r['call_id']:r for r in load('SCORING-REFERENCE.json')}
    raw=json.loads(rawfile.read_text());raw=raw['rows'] if isinstance(raw,dict) else raw
    assert len(raw)==len({r['call_id'] for r in raw})==576;rawix={r['call_id']:r for r in raw};assert set(rawix)=={c['call_id'] for c in calls}
    rows=[]
    for c in calls:
        r=rawix[c['call_id']];assert r['model']==c['model'] and r['messages']==c['messages'];sc=score(r['generated_text'],c,refs[c['call_id']]);rows.append(c|dict(raw=r,reference=refs[c['call_id']],score=sc,categories=categories(sc,c)))
    ix={r['call_id']:r for r in rows};selected=[];selection_pairs=[]
    for p in load('SELECTION-PLAN.json'):
        orig,single=ix[p['original_call_id']],ix[p['single_call_id']]
        assert single['condition']=='SINGLE' and p['selected_messages']==single['messages'] and p['selected_prompt_sha256']==single['prompt_sha256']
        assert all(orig['reference'][k]==single['reference'][k] for k in ['role_a','role_b','occurred'])
        selected.append(p|dict(score=single['score'],source_raw=single['raw'],source_forward_n=single['raw']['row_forward_n'],new_calls=0,new_forwards=0,identity='DERIVED_BY_EXACT_CURRENT_SINGLE_REUSE_NOT_NEW_GENERATION'))
        selection_pairs.append(p|paired_detail(orig,single))
    profiles=[]
    for model,lang,cond in itertools.product(['qwen','llama'],['JA','ZH'],['SINGLE','DISJOINT','REVERSE','CROSS_ACTOR','CROSS_UNDERGOER']):
        rr=[r for r in rows if r['model']==model and r['language']==lang and r['condition']==cond]
        def profile(sub):return {**{k:counts(sub,k) for k in COMPONENTS},'categories':category_counts(sub),'format':dict(Counter(r['score']['format_compliance'] for r in sub))}
        facets={k:{val:profile([r for r in rr if r[k]==val]) for val in sorted({r[k] for r in rr})} for k in ['lexical_family','fact','target_label','position']}
        crossed=[{'position':pos,'target_label':lab,'profile':profile([r for r in rr if r['position']==pos and r['target_label']==lab])} for pos,lab in itertools.product(sorted({r['position'] for r in rr}),['R1','R2'])]
        profiles.append(dict(model=model,language=lang,condition=cond,all=profile(rr),facets=facets,position_by_label=crossed))
    context=[];cplan=load('CONTRAST-PLAN.json');context_pairs=[]
    for p in cplan:context_pairs.append(p|paired_detail(ix[p['control_call_id']],ix[p['challenge_call_id']]))
    for model,lang,cond in itertools.product(['qwen','llama'],['JA','ZH'],['REVERSE','CROSS_ACTOR','CROSS_UNDERGOER']):
        pp=[p for p in cplan if p['model']==model and p['language']==lang and p['condition']==cond]
        def cmp(ps):return compare([ix[p['control_call_id']] for p in ps],[ix[p['challenge_call_id']] for p in ps])
        facets={k:{v:cmp([p for p in pp if p[k]==v]) for v in sorted({p[k] for p in pp})} for k in ['lexical_family','fact','target_label','position']}
        crossed=[{'position':pos,'target_label':lab,'contrast':cmp([p for p in pp if p['position']==pos and p['target_label']==lab])} for pos,lab in itertools.product(['FIRST','LAST'],['R1','R2'])]
        context.append(dict(model=model,language=lang,condition=cond,all=cmp(pp),facets=facets,position_by_label=crossed))
    selection_summary=[]
    for model,lang in itertools.product(['qwen','llama'],['JA','ZH']):
        pp=[p for p in load('SELECTION-PLAN.json') if p['model']==model and p['language']==lang]
        def cmpselect(ps):return {k:compare([ix[p['original_call_id']] for p in ps],[ix[p['single_call_id']] for p in ps],k) for k in COMPONENTS}
        selection_summary.append(dict(model=model,language=lang,all=cmpselect(pp),facets={k:{v:cmpselect([p for p in pp if p[k]==v]) for v in sorted({p[k] for p in pp})} for k in ['condition','position','target_label','fact','lexical_family']}))
    screens=[]
    for model,lang in itertools.product(['qwen','llama'],['JA','ZH']):
        single=counts([r for r in rows if r['model']==model and r['language']==lang and r['condition']=='SINGLE'],'participant');screens.append(dict(model=model,language=lang,single=single,screen_pass=single['C']>=15,primary=model=='qwen' and lang=='ZH'))
    primary_cs=[c for c in context if c['model']=='qwen' and c['language']=='ZH' and c['condition'] in ['CROSS_ACTOR','CROSS_UNDERGOER']]
    singlepass=next(x['screen_pass'] for x in screens if x['primary']);signals=[dict(condition=c['condition'],W_lower_positive=c['all']['W_lower']>0,positive_lexical_families=sum(v['W_difference']>0 for v in c['facets']['lexical_family'].values())) for c in primary_cs]
    costs=[]
    for model,cond in itertools.product(['qwen','llama'],['SINGLE','DISJOINT','REVERSE','CROSS_ACTOR','CROSS_UNDERGOER']):
        sub=[r['raw'] for r in rows if r['model']==model and r['condition']==cond]
        costs.append(dict(model=model,condition=cond,actual_calls=0 if synthetic else len(sub),synthetic_rows=len(sub) if synthetic else 0,input_tokens=sum(r.get('input_token_n',0) for r in sub),output_tokens=sum(r.get('generated_token_n',0) for r in sub),forwards=sum(r['row_forward_n'] for r in sub),seconds=sum(r.get('row_seconds',0) for r in sub)))
    summary=dict(experiment_id='EXP-20260908-B19',actual_model_outputs=0 if synthetic else 576,synthetic_rows=576 if synthetic else 0,actual_forwards=sum(r['row_forward_n'] for r in raw),single_actual_outputs=0 if synthetic else 64,selected_derived_records=512,selection_new_forwards=0,costs=costs,profiles=profiles,context_contrasts=context,selection_summary=selection_summary,single_screens=screens,primary_descriptive_support={'model':'qwen','language':'ZH','single_screen_pass':singlepass,'conditions':signals,'supported':singlepass and all(x['W_lower_positive'] and x['positive_lexical_families']>=3 for x in signals),'identity':'DESCRIPTIVE_AUTHOR_DEVELOPMENT_SIGNAL_NOT_CONFIRMATION'},independent_human_gold=0,automatic_B20=False,github_paused=True)
    out.mkdir(parents=True,exist_ok=False)
    for n,x in [('ACTUAL-SCORED-ROWS.AI.json',rows),('SELECTED-DERIVED-RECORDS.AI.json',selected),('SELECTION-PAIRS.AI.json',selection_pairs),('CONTEXT-PAIRS.AI.json',context_pairs),('SUMMARY.json',summary)]:
        (out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
    return summary
if __name__=='__main__':
    s=analyze(Path(__file__).resolve().parent,Path(sys.argv[1]),Path(sys.argv[2]));print(json.dumps(s['primary_descriptive_support']))
