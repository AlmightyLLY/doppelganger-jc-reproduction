"""Frozen B22 scoring and descriptive identification bounds; no model execution."""
from pathlib import Path
from collections import Counter
import json,copy,itertools,argparse
from score_b09 import score
from analysis_common import categories
ROLES=['role_a','role_b','participant','participant_set']
NA='N/A_INTERVENED'
def participant_set(sc,ref):
 a,b=sc['decoded_names']['role_a'],sc['decoded_names']['role_b'];target=[ref['role_a'],ref['role_b']]
 if a is not None and b is not None:return 'C' if Counter([a,b])==Counter(target) else 'W'
 return 'W' if any(x is not None and x not in target for x in [a,b]) else 'U'
def grade_forced(raw,call,ref):
 sc=score(raw,call,ref);sc['labels']['participant_set']=participant_set(sc,ref)
 sc['labels']['occurrence']=sc['labels']['record']=NA
 sc['occurrence_reason']=NA;sc['unsupported_assertion']=None;sc['explicit_occurrence_contradiction']=None
 sc['identity']='AI_ROLE_SCORING_FOR_INTERVENED_RESPONSE_NOT_HUMAN_GOLD'
 return sc
def count(labels):
 assert labels and all(x in ['C','W','U'] for x in labels)
 c=Counter(labels);return dict(n=len(labels),**{x:c[x] for x in ['C','W','U']})
def delta(challenge,control):
 a,b=count(challenge),count(control);assert a['n']==b['n'];n=a['n']
 return dict(challenge=a,control=b,n=n,W_difference=(a['W']-b['W'])/n,lower=(a['W']-b['W']-b['U'])/n,upper=(a['W']+a['U']-b['W'])/n)
def gamma(yes_challenge,yes_control,no_challenge,no_control):
 y=delta(yes_challenge,yes_control);n=delta(no_challenge,no_control)
 assert y['n']==n['n']
 return dict(n=y['n'],YES=y,NO=n,Gamma=y['W_difference']-n['W_difference'],lower=y['lower']-n['upper'],upper=y['upper']-n['lower'])
def transitions(old,new):
 assert len(old)==len(new);a,b=count(old),count(new);t=Counter(x+'->'+y for x,y in zip(old,new))
 return dict(n=len(old),old=a,new=b,transitions={x+'->'+y:t[x+'->'+y] for x in ['C','W','U'] for y in ['C','W','U']},definite_rescues=t['W->C'],definite_harms=t['C->W'],new_unresolved=t['C->U']+t['W->U'],condition_role_improvement=b['W']<a['W'] and b['C']>a['C'])
def H(group):
 allg=group['all'];fam=group['families'];names=group['name_sets']
 assert allg['n']==8 and len(fam)==4 and all(x['n']==2 for x in fam.values()) and len(names)==2 and all(x['n']==4 for x in names.values())
 return allg['lower']>0 and sum(x['lower']>0 for x in fam.values())>=3 and all(x['lower']>0 for x in names.values())
def summarize_gamma(rows,model,condition,fact,component='participant'):
 rows=[r for r in rows if r['model']==model and r['condition']==condition and r['fact']==fact and r['prefix_value'] in ['YES','NO']]
 if len(rows)!=32 or any(r.get('score') is None for r in rows):return dict(status='UNAVAILABLE_TECHNICAL_OR_NOT_RUN',H=None)
 def calc(rs):
  cells=[]
  for p,d in [('YES','YES'),('YES','NO'),('NO','YES'),('NO','NO')]:
   part=sorted([r for r in rs if r['prefix_value']==p and r['distractor_fact']==d],key=lambda r:r['base_id'])
   cells.append(part)
  assert len({tuple(r['base_id'] for r in c) for c in cells})==1
  return gamma(*[[r['score']['labels'][component] for r in c] for c in cells])
 out=dict(status='COMPLETE',model=model,condition=condition,target_fact=fact,component=component,all=calc(rows),families={f:calc([r for r in rows if r['lexical_family']==f]) for f in sorted({r['lexical_family'] for r in rows})},name_sets={n:calc([r for r in rows if r['name_set']==n]) for n in ['N1','N2']})
 out['H']=H(out) if component=='participant' else None;out['primary']=model=='qwen' and condition=='CROSS_ACTOR' and fact=='NO' and component=='participant'
 return out
def analyze(base,plans,actual,model_valid):
 byid={r['call_id']:r for r in actual};assert len(byid)==len(actual)
 bm={b['B21_call_id']:b for b in base};assert set(byid)<=set(c['call_id'] for c in plans)
 rows=[]
 for b in base:
  s=copy.deepcopy(b['metadata']);s['prefix_value']='NATURAL';s['B21_call_id']=b['B21_call_id'];s['status']='REUSED_B21_FROZEN';s['score']['labels']['participant_set']=participant_set(s['score'],s['reference']);rows.append(s)
 for c in plans:
  b=bm[c['B21_call_id']];s=b['metadata'];a=byid.get(c['call_id']);r={k:copy.deepcopy(s[k]) for k in ['model','base_id','source_id','fact','lexical_family','name_set','condition','distractor_fact','source_text','messages','target_pair','distractor_pair','position','target_label']}
  r.update(plan=copy.deepcopy(c),call_id=c['call_id'],B21_call_id=c['B21_call_id'],prefix_value=c['prefix_value'],actual=a,score=None,categories=None,status='NOT_RUN' if a is None else 'TECHNICALLY_INVALID_MODEL' if not model_valid.get(c['model'],False) else 'VALID_FORCED_CONTINUATION')
  if r['status']=='VALID_FORCED_CONTINUATION':
   assert a['prefix_token_ids']==c['prefix_token_ids'] and a['prefix_text']==c['prefix_text'] and a['model_input_ids']==c['model_input_ids']
   r['score']=grade_forced(a['full_response'],s,s['reference']);r['categories']=categories(r['score'],s)
  rows.append(r)
 comparisons=[summarize_gamma(rows,m,rel,fact,component) for m,rel,fact,component in itertools.product(['qwen','llama'],['DISJOINT','CROSS_ACTOR'],['YES','NO'],ROLES)]
 lookup={(r['B21_call_id'],r['prefix_value']):r for r in rows};pairs=[]
 for b in base:
  cid=b['B21_call_id']
  for before,after in [('NATURAL','YES'),('NATURAL','NO'),('YES','NO')]:
   x,y=lookup[cid,before],lookup[cid,after];valid=x['score'] is not None and y['score'] is not None
   pair={k:x[k] for k in ['model','base_id','source_id','fact','lexical_family','name_set','condition','distractor_fact']}
   pair.update(B21_call_id=cid,before=before,after=after,before_call_id=x['call_id'],after_call_id=y['call_id'],status='AVAILABLE' if valid else 'UNAVAILABLE_TECHNICAL_OR_NOT_RUN',transitions={k:x['score']['labels'][k]+'->'+y['score']['labels'][k] for k in ROLES} if valid else None)
   pairs.append(pair)
 aggregates=[]
 for m,rel,fact,d in itertools.product(['qwen','llama'],['SINGLE','DISJOINT','CROSS_ACTOR'],['YES','NO'],['NONE','YES','NO']):
  if (rel=='SINGLE')!=(d=='NONE'):continue
  subset=[p for p in pairs if p['model']==m and p['condition']==rel and p['fact']==fact and p['distractor_fact']==d]
  for before,after in [('NATURAL','YES'),('NATURAL','NO'),('YES','NO')]:
   current=[p for p in subset if p['before']==before and p['after']==after]
   facets=[('all','all',current)]+[(k,v,[p for p in current if p[k]==v]) for k in ['lexical_family','name_set'] for v in sorted({p[k] for p in current})]
   for facet,value,ps in facets:
    metrics={}
    if all(p['transitions'] is not None for p in ps):
     for k in ROLES:metrics[k]=transitions([p['transitions'][k].split('->')[0] for p in ps],[p['transitions'][k].split('->')[1] for p in ps])
    aggregates.append(dict(model=m,condition=rel,target_fact=fact,distractor_fact=d,before=before,after=after,facet=facet,value=value,n=len(ps),metrics=metrics or None))
 return dict(rows=rows,gamma=comparisons,pairs=pairs,transition_aggregates=aggregates,identity='DEVELOPMENT_DESCRIPTIVE_NOT_INDEPENDENT_GOLD',natural_positions=160,planned_forced_positions=320,independent_base_groups=8)
def main():
 p=argparse.ArgumentParser();p.add_argument('--actual',type=Path,required=True);p.add_argument('--validity',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parent;rd=lambda p:json.loads(p.read_text())
 out=analyze(rd(root/'BASELINES.json')['rows'],rd(root/'CALL-PLAN.json')['calls'],rd(a.actual)['rows'],rd(a.validity)['model_valid']);a.output.mkdir(exist_ok=False)
 for k,v in out.items():
  if isinstance(v,list):(a.output/(k.upper()+'.AI.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
 (a.output/'SUMMARY.json').write_text(json.dumps({k:v for k,v in out.items() if not isinstance(v,list)},ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':main()
