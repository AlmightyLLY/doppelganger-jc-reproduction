"""Pure, tested B22 ordering/token-budget/match gate. No reference in sampling."""
class MatchFailure(RuntimeError):pass
def decode_suffix(input_ids,prefix_ids,eos,choose,decode,max_total=256,max_input=4096):
 assert 0<len(prefix_ids)<max_total and 0<len(input_ids) and len(input_ids)+len(prefix_ids)<=max_input
 assert not any(t in eos for t in prefix_ids)
 context=list(input_ids)+list(prefix_ids);suffix=[];stopped=False
 for _ in range(max_total-len(prefix_ids)):
  chosen=choose(context);assert isinstance(chosen,int);suffix.append(chosen)
  if chosen in eos:stopped=True;break
  context.append(chosen)
 whole=list(prefix_ids)+suffix
 return dict(suffix_token_ids=suffix,suffix_token_n=len(suffix),prefix_token_ids=list(prefix_ids),prefix_token_n=len(prefix_ids),full_token_ids=whole,total_output_token_n=len(whole),row_forward_n=len(suffix),stopped_on_eos=stopped,finish_reason='EOS' if stopped else 'LENGTH',suffix_text=decode(suffix[:-1] if stopped else suffix),full_response=decode(whole[:-1] if stopped else whole),model_input_ids=list(input_ids)+list(prefix_ids))
def match(row,reference):
 return dict(suffix_tokens_exact=row['suffix_token_ids']==reference['generated_token_ids'][row['prefix_token_n']:],all_tokens_exact=row['full_token_ids']==reference['generated_token_ids'],eos_exact=row['stopped_on_eos']==reference['stopped_on_eos'],finish_reason_exact=row['finish_reason']==reference['finish_reason'],raw_exact=row['full_response']==reference['generated_text'])
def execute_pairs(calls,references,execute,record):
 assert len(calls)%2==0 and len({c['call_id'] for c in calls})==len(calls)
 for first,second in zip(calls[::2],calls[1::2]):
  assert first['B21_call_id']==second['B21_call_id'] and first['matching_branch'] and not second['matching_branch']
  assert first['branch_order']==1 and second['branch_order']==2 and {first['prefix_value'],second['prefix_value']}=={'YES','NO'}
  ref=references[first['B21_call_id']]
  assert first['prefix_value']==first['natural_prefix_value'] and first['prefix_token_ids']==ref['generated_token_ids'][:first['prefix_token_n']]
  # execute receives only this call. Reference suffix/people never enter the sampler.
  row=execute(first);checks=match(row,ref);row['matching_checks']=checks;row['matching_branch_pass']=all(checks.values());record(row)
  if not row['matching_branch_pass']:raise MatchFailure('Natural-value match failed: '+first['call_id'])
  other=execute(second);other['matching_checks']=None;other['matching_branch_pass']=None;record(other)
