"""Frozen prospective B20 analysis. Synthetic mode cannot count model calls or forwards."""
from pathlib import Path
import json,itertools,sys
from collections import Counter,defaultdict
from score_b09 import score
from analysis_common import COMPONENTS,categories,counts,category_counts,compare,paired_detail
FACETS=['lexical_family','mapping','novelty_group']
GROUP=['pair_type','model','voice','fact','condition','distractor_fact']
def profile(rows):
 return {**{k:counts(rows,k) for k in COMPONENTS},'categories':category_counts(rows),'format':dict(Counter(r['score']['format_compliance'] for r in rows)),'language':dict(Counter(r['score']['language_status'] for r in rows))}
def analyze(root,rawfile,out,synthetic=False):
 load=lambda n:json.loads((root/n).read_text());calls=load('CALL-PLAN.json')['A'];refs={r['call_id']:r for r in load('SCORING-REFERENCE.json')};raw=json.loads(rawfile.read_text());raw=raw['rows'] if isinstance(raw,dict) else raw
 assert len(raw)==len({r['call_id'] for r in raw})==320,'Incomplete/unresolved execution must be recorded separately, never filled as CWU'
 rawix={r['call_id']:r for r in raw};assert set(rawix)=={c['call_id'] for c in calls}
 rows=[]
 for c in calls:
  r=rawix[c['call_id']];assert r['model']==c['model'] and r['messages']==c['messages'];sc=score(r['generated_text'],c,refs[c['call_id']]);rows.append(c|dict(raw=r,reference=refs[c['call_id']],score=sc,categories=categories(sc,c)))
 if synthetic:assert all(r['row_forward_n']==0 for r in raw)
 ix={r['call_id']:r for r in rows};plan=load('PAIR-PLAN.json');pairs=[p|paired_detail(ix[p['control_call_id']],ix[p['challenge_call_id']]) for p in plan]
 def cmp(ps,reverse=False):
  aa=[ix[p['control_call_id']] for p in ps];bb=[ix[p['challenge_call_id']] for p in ps]
  if reverse:aa,bb=bb,aa
  detail=[paired_detail(a,b) for a,b in zip(aa,bb)]
  return {**{k:compare(aa,bb,k) for k in COMPONENTS},'control_categories':category_counts(aa),'challenge_categories':category_counts(bb),'hidden_component_harm_on_original_record_W':sum(x['added_component_harm_on_original_record_W'] for x in detail),'any_component_harm':sum(bool(x['new_component_harms']) for x in detail)}
 def summary_group(meta,ps):
  result=meta|dict(all=cmp(ps),facets={k:{v:cmp([p for p in ps if p[k]==v]) for v in sorted({p[k] for p in ps})} for k in FACETS},descriptive_metadata={k:{v:cmp([p for p in ps if p[k]==v]) for v in sorted({p[k] for p in ps})} for k in ['target_label','assigned_position']},independent_sample=False)
  if meta['pair_type']=='VOICE':result['passive_to_active_replacement']=dict(identity='AUTHOR_PREWRITTEN_EQUIVALENT_INPUT_NOT_DEPLOYABLE_GENERATED_REPAIR',all=cmp(ps,True),facets={k:{v:cmp([p for p in ps if p[k]==v],True) for v in sorted({p[k] for p in ps})} for k in FACETS})
  return result
 groups=defaultdict(list)
 for p in plan:groups[tuple(p[k] for k in GROUP)].append(p)
 comparisons=[summary_group(dict(zip(GROUP,key)),ps) for key,ps in groups.items()]
 # Merged mismatch report supplements, never replaces both target-polarity directions.
 merged=[]
 for model,voice,cond in itertools.product(['qwen','llama'],['ACTIVE','PASSIVE'],['DISJOINT','CROSS_ACTOR']):
  ps=[p for p in plan if p['pair_type']=='INCONSISTENCY' and p['model']==model and p['voice']==voice and p['condition']==cond];assert len(ps)==16
  merged.append(summary_group(dict(pair_type='INCONSISTENCY_MERGED',model=model,voice=voice,fact='BOTH',condition=cond,distractor_fact='MISMATCH_VS_MATCH',warning='Report the two target-polarity directions separately even if their merged effect cancels.'),ps))
 profiles=[];screens=[]
 for model,voice,fact in itertools.product(['qwen','llama'],['ACTIVE','PASSIVE'],['YES','NO']):
  single=[r for r in rows if r['model']==model and r['voice']==voice and r['fact']==fact and r['condition']=='SINGLE'];assert len(single)==8
  screens.append(dict(model=model,voice=voice,fact=fact,single=profile(single),screen_pass=counts(single,'participant')['C']>=7))
  for cond,df in [('SINGLE','NONE')]+list(itertools.product(['DISJOINT','CROSS_ACTOR'],['YES','NO'])):
   rr=[r for r in rows if r['model']==model and r['voice']==voice and r['fact']==fact and r['condition']==cond and r['distractor_fact']==df];assert len(rr)==8
   profiles.append(dict(model=model,voice=voice,fact=fact,condition=cond,distractor_fact=df,all=profile(rr),facets={k:{v:profile([r for r in rr if r[k]==v]) for v in sorted({r[k] for r in rr})} for k in FACETS}))
 screenix={(s['model'],s['voice'],s['fact']):s['screen_pass'] for s in screens}
 def evidence(comp):return dict(fact=comp['fact'],distractor_fact=comp['distractor_fact'],W_lower=comp['all']['participant']['W_lower'],positive_families=sum(x['participant']['W_difference']>0 for x in comp['facets']['lexical_family'].values()),family_differences={k:x['participant']['W_difference'] for k,x in comp['facets']['lexical_family'].items()},mapping_differences={k:x['participant']['W_difference'] for k,x in comp['facets']['mapping'].items()},novelty_differences={k:x['participant']['W_difference'] for k,x in comp['facets']['novelty_group'].items()})
 inc=[evidence(c) for c in comparisons if c['pair_type']=='INCONSISTENCY' and c['model']=='qwen' and c['voice']=='PASSIVE' and c['condition']=='CROSS_ACTOR'];neg=[evidence(c) for c in comparisons if c['pair_type']=='VOICE' and c['model']=='qwen' and c['fact']=='NO' and c['condition']=='CROSS_ACTOR'];assert len(inc)==len(neg)==2
 markers={}
 for name,ev,keys in [('polarity_inconsistency',inc,[('qwen','PASSIVE',f) for f in ['YES','NO']]),('negative_passive_vulnerability',neg,[('qwen',v,'NO') for v in ['ACTIVE','PASSIVE']])]:
  passed=all(screenix[k] for k in keys);markers[name]=dict(single_layers_pass=passed,evidence=ev,supported=passed and all(x['W_lower']>0 and x['positive_families']>=3 for x in ev),identity='DESCRIPTIVE_DEVELOPMENT_NOT_CONFIRMATION_NOT_EXCLUSIVE_CAUSAL_ATTRIBUTION')
 replacements=[dict(pair_id=p['pair_id']+'-REPLACEMENT',original_call_id=p['challenge_call_id'],replacement_call_id=p['control_call_id'],model=p['model'],base_id=p['base_id'],fact=p['fact'],condition=p['condition'],distractor_fact=p['distractor_fact'],identity='AUTHOR_PREWRITTEN_ACTIVE_SOURCE_NOT_MODEL_REWRITE',**paired_detail(ix[p['challenge_call_id']],ix[p['control_call_id']])) for p in plan if p['pair_type']=='VOICE']
 costs=[dict(model=m,actual_calls=0 if synthetic else len(rr),synthetic_rows=len(rr) if synthetic else 0,forwards=sum(r['raw']['row_forward_n'] for r in rr),input_tokens=sum(r['raw'].get('input_token_n',0) for r in rr),output_tokens=sum(r['raw'].get('generated_token_n',0) for r in rr),row_seconds=sum(r['raw'].get('row_seconds',0) for r in rr)) for m in ['qwen','llama'] for rr in [[r for r in rows if r['model']==m]]]
 summary=dict(experiment_id='EXP-20260908-B20',actual_model_outputs=0 if synthetic else 320,synthetic_rows=320 if synthetic else 0,actual_forwards=sum(r['row_forward_n'] for r in raw),single_screens=screens,profiles=profiles,comparisons=comparisons,merged_inconsistency=merged,markers=markers,costs=costs,independent_human_gold=0,automatic_B21=False)
 out.mkdir(parents=True,exist_ok=False)
 for n,x in [('ACTUAL-SCORED-ROWS.AI.json',rows),('PAIRED-TRANSITIONS.AI.json',pairs),('PASSIVE-TO-ACTIVE-REPLACEMENTS.AI.json',replacements),('SUMMARY.json',summary)]: (out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
 return summary
if __name__=='__main__':
 s=analyze(Path(__file__).resolve().parent,Path(sys.argv[1]),Path(sys.argv[2]));print(json.dumps(s['markers']))
