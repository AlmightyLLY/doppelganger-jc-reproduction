"""Prospective B19 observable categories and paired selection analysis."""
from pathlib import Path
import json,itertools,sys
from collections import Counter
from score_b09 import score
COMPONENTS=['role_a','role_b','participant','occurrence','record']
def categories(sc,call):
    a,b=sc['decoded_names']['role_a'],sc['decoded_names']['role_b'];matches=[]
    if a is None or b is None:return {'matches':[],'status_category':'UNRESOLVED','ambiguous_named_matches':False,'pair':[a,b],'interpretation':'OUTPUT_DESCRIPTION_NOT_INTERNAL_SELECTION'}
    target=call['target_pair'];dist=call['distractor_pair'];candidates={'TARGET':target,'TARGET_REVERSED':target[::-1]}
    if dist is not None:candidates.update(DISTRACTOR=dist,DISTRACTOR_REVERSED=dist[::-1])
    matches=[name for name,pair in candidates.items() if [a,b]==pair]
    status='MATCHED' if matches else 'DUPLICATE_PERSON' if a==b else 'OTHER_COMPLETE'
    return dict(matches=matches,status_category=status,ambiguous_named_matches=len(matches)>1,pair=[a,b],interpretation='OUTPUT_DESCRIPTION_NOT_INTERNAL_SELECTION')
def counts(rows,key):
    c=Counter(r['score']['labels'][key] for r in rows);return {'n':len(rows),**{k:c[k] for k in ['C','W','U']}}
def category_counts(rows):
    return {'n':len(rows),'set_match_counts':dict(Counter(k for r in rows for k in r['categories']['matches'])),'status_counts':dict(Counter(r['categories']['status_category'] for r in rows)),'ambiguous_named_matches':sum(r['categories']['ambiguous_named_matches'] for r in rows),'warning':'Set matches may overlap and need not sum to n.'}
def compare(control,challenge,key='participant'):
    assert len(control)==len(challenge)>0
    a,b=counts(control,key),counts(challenge,key);n=len(control);trans=Counter(x['score']['labels'][key]+'->'+y['score']['labels'][key] for x,y in zip(control,challenge))
    return {'n':n,'control':a,'challenge':b,'W_difference':(b['W']-a['W'])/n,'C_difference':(b['C']-a['C'])/n,'W_lower':(b['W']-a['W']-a['U'])/n,'W_upper':(b['W']+b['U']-a['W'])/n,'C_lower':(b['C']-a['C']-a['U'])/n,'C_upper':(b['C']+b['U']-a['C'])/n,'transitions':{x+'->'+y:trans[x+'->'+y] for x in ['C','W','U'] for y in ['C','W','U']}}
def paired_detail(a,b):
    aa,bb=a['score']['labels'],b['score']['labels'];harms=[k for k in ['role_a','role_b','occurrence'] if aa[k]=='C' and bb[k] in ['W','U']]
    return dict(transitions={k:aa[k]+'->'+bb[k] for k in COMPONENTS},new_component_harms=harms,added_component_harm_on_original_record_W=aa['record']=='W' and bool(harms),added_role_harm_on_original_occurrence_W=aa['occurrence']=='W' and any(k in harms for k in ['role_a','role_b']))
