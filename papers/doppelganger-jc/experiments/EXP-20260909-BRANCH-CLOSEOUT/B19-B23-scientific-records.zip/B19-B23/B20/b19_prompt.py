from joint_prompt import NAMES,prompt as old_prompt
def prompt(lang,source,verb,target_label):
    assert target_label in ['R1','R2']
    text=old_prompt(lang,'@@SOURCE@@',verb)
    oldheader=text.split('\n')[0]
    newheader=('以下は架空の人物についての記録です。各番号は独立した記録を表し、時間の順序を示しません。対象はR1だけです。' if lang=='JA' else '以下是关于虚构人物的记录。各编号表示独立记录，不表示时间先后。只回答R1。')
    return text.replace(oldheader,newheader,1).replace('R1',target_label).replace('@@SOURCE@@',source)
