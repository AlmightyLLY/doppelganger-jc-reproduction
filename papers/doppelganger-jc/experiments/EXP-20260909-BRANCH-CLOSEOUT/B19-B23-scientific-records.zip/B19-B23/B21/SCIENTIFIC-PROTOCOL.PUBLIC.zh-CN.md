# B21 科学记录公开摘录

> PUBLIC_DERIVED：仅摘录原文件的科学段落；不是新的预注册，不改变历史评分。未摘录的运行组织、个人审核入口及原件交付内容为 PUBLIC_OMITTED。完整实际提示和原始回答在独立逐字节文件中保留。

## 目的
在新姓名材料复查B20较窄不对称，检验干扰语态及精确“没有被”词串是否必要；Qwen中文唯一主要，Llama中文边界。

## 规模
4词×2名单×每组20输入×2模型=320；32 SINGLE、288双记录。160不同消息，16目标核心。词项和名单相关，变体不是独立n。

## 科学对照
目标固定被动YES/NO；干扰ACTIVE/PASSIVE×YES/NO，两种人物关系；NO目标另加PASSIVE WEI“未被”。SINGLE及DISJOINT不可省略。

## 筛查
每模型×目标YES/NO的SINGLE各n8，角色C≥7。发生基线另报；不筛去失败组。

## 稳健正方向
总n8角色W差下界>0，至少3/4词项各n2的下界>0，两名单各n4下界均>0。描述规则，不是显著性检验。

## 未决界
challenge减control的W界=[W_challenge−W_control−U_control, W_challenge+U_challenge−W_control]/n；不是置信区间。

## R
主要Qwen CROSS_ACTOR的PASSIVE Delta_N稳健正，YES/NO SINGLE均通过，且Delta_N下界−Delta_Y上界>0。Delta_N是NO目标下YES干扰减NO干扰；Delta_Y是YES目标下NO减YES。

## A与V
A：ACTIVE Delta_N稳健正且NO SINGLE通过。V：PASSIVE YES减PASSIVE WEI稳健正且NO SINGLE通过。分别报告；R失败不能靠A/V挽救。

## 扩展否定
R且A且V；仅排除必须精确重复“没有被”的简单解释，不证明抽象语义或机制。

## 表达依赖
R且WEI减PASSIVE NO、ACTIVE NO减PASSIVE NO两项均稳健正；若A/V仍正须同时报告部分保留，不硬说其他表达无效。

## 主动天花板
NO目标CROSS_ACTOR两个ACTIVE肯否均角色C≥7/8，且PASSIVE YES减ACTIVE YES稳健正。可与其他标签并存，不以主动零差证明无效。

## 配对口径
848有向配对=CONTEXT288+OVERLAP144+POLARITY128+DISTRACTOR_VOICE128+WORDING160；106格各n8。含64个反向重复比较，784个不同无向调用对；复用不增加独立样本或推理。

## 完整报告
保留角色双方、角色对、发生、完整C/W/U，语言/格式、集合式角色类别、全部转移、完整W→W中的新增分项害；64个作者转为WEI的替换诊断不是模型修复。每词/名单及编号/位置描述分层全报。

## 不同结果措施
R或SINGLE失败：停止扩量，回Main复评。R保留但A/V或表达边界混合：如实未区分。RAV同过：仅较广否定相关候选。表达依赖：收缩解释。天花板：记录语态边界。均无自动B22或提示搜索。

## 来源与限制
协议 SCIENTIFIC-PROTOCOL.PUBLIC.zh-CN.md；名字仅核查B16–B20全部CALL-PLAN实际消息（含所有语言/模型），无命中或完整消息重复；不是全项目/预训练未见。四作者词项，了/长度/语用未隔离，词内姓名与编号位置未独立。
