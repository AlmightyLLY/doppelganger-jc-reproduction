"""Prospective B21 descriptive rules; synthetic mode has zero inference."""
from pathlib import Path
import json,itertools,sys
from collections import Counter,defaultdict
from score_b09 import score
from analysis_common import COMPONENTS,categories,counts,category_counts,compare,paired_detail
FACETS=['lexical_family','name_set']
GROUP=['pair_type','model','fact','condition','contrast']
def profile(rows):
 return {**{k:counts(rows,k) for k in COMPONENTS},'categories':category_counts(rows),'format':dict(Counter(r['score']['format_compliance'] for r in rows)),'language':dict(Counter(r['score']['language_status'] for r in rows))}
def analyze(root,rawfile,out,synthetic=False):
 load=lambda n:json.loads((root/n).read_text());calls=load('CALL-PLAN.json')['A'];refs={r['call_id']:r for r in load('SCORING-REFERENCE.json')};raw=json.loads(rawfile.read_text());raw=raw['rows'] if isinstance(raw,dict) else raw
 assert len(raw)==len({r['call_id'] for r in raw})==320,'Incomplete execution must be reported separately, never filled as CWU'
 rawix={r['call_id']:r for r in raw};assert set(rawix)=={c['call_id'] for c in calls}
 if synthetic:assert all(r['row_forward_n']==0 and r['identity']=='SYNTHETIC_NOT_MODEL_OUTPUT' for r in raw)
 rows=[]
 for c in calls:
  r=rawix[c['call_id']];assert r['model']==c['model'] and r['messages']==c['messages'];sc=score(r['generated_text'],c,refs[c['call_id']]);rows.append(c|dict(raw=r,reference=refs[c['call_id']],score=sc,categories=categories(sc,c)))
 ix={r['call_id']:r for r in rows};plan=load('PAIR-PLAN.json');pairs=[p|paired_detail(ix[p['control_call_id']],ix[p['challenge_call_id']]) for p in plan]
 def cmp(ps,reverse=False):
  aa=[ix[p['control_call_id']] for p in ps];bb=[ix[p['challenge_call_id']] for p in ps]
  if reverse:aa,bb=bb,aa
  detail=[paired_detail(a,b) for a,b in zip(aa,bb)]
  return {**{k:compare(aa,bb,k) for k in COMPONENTS},'control_categories':category_counts(aa),'challenge_categories':category_counts(bb),'hidden_component_harm_on_original_record_W':sum(x['added_component_harm_on_original_record_W'] for x in detail),'any_component_harm':sum(bool(x['new_component_harms']) for x in detail)}
 groups=defaultdict(list)
 for p in plan:groups[tuple(p[k] for k in GROUP)].append(p)
 comparisons=[]
 for key,ps in groups.items():
  meta=dict(zip(GROUP,key));result=meta|dict(all=cmp(ps),facets={k:{v:cmp([p for p in ps if p[k]==v]) for v in sorted({p[k] for p in ps})} for k in FACETS},descriptive_metadata={k:{v:cmp([p for p in ps if p[k]==v]) for v in sorted({p[k] for p in ps})} for k in ['target_label','assigned_position']},independent_sample=False)
  if meta['contrast'] in ['PASSIVE_NO_MINUS_WEI','ACTIVE_NO_MINUS_WEI']:result['author_input_to_WEI']=dict(identity='AUTHOR_PREWRITTEN_INPUT_NOT_MODEL_REPAIR',all=cmp(ps,True),facets={k:{v:cmp([p for p in ps if p[k]==v],True) for v in sorted({p[k] for p in ps})} for k in FACETS})
  comparisons.append(result)
 profiles=[];screens=[]
 for model,fact in itertools.product(['qwen','llama'],['YES','NO']):
  single=[r for r in rows if r['model']==model and r['fact']==fact and r['condition']=='SINGLE'];assert len(single)==8
  screens.append(dict(model=model,fact=fact,single=profile(single),screen_pass=counts(single,'participant')['C']>=7))
  conditions=[('SINGLE','NONE','NONE')]+list(itertools.product(['DISJOINT','CROSS_ACTOR'],['ACTIVE','PASSIVE'],['YES','NO']))+([(k,'PASSIVE','WEI') for k in ['DISJOINT','CROSS_ACTOR']] if fact=='NO' else [])
  for cond,dv,dw in conditions:
   rr=[r for r in rows if (r['model'],r['fact'],r['condition'],r['distractor_voice'],r['distractor_wording'])==(model,fact,cond,dv,dw)];assert len(rr)==8
   profiles.append(dict(model=model,fact=fact,condition=cond,distractor_voice=dv,distractor_wording=dw,all=profile(rr),facets={k:{v:profile([r for r in rr if r[k]==v]) for v in sorted({r[k] for r in rr})} for k in FACETS}))
 screenix={(s['model'],s['fact']):s['screen_pass'] for s in screens}
 cix={(c['pair_type'],c['model'],c['fact'],c['condition'],c['contrast']):c for c in comparisons}
 def evidence(c):
  p=c['all']['participant'];fam={k:v['participant']['W_lower'] for k,v in c['facets']['lexical_family'].items()};ns={k:v['participant']['W_lower'] for k,v in c['facets']['name_set'].items()}
  return dict(comparison={k:c[k] for k in GROUP},W_difference=p['W_difference'],W_lower=p['W_lower'],W_upper=p['W_upper'],family_lower=fam,name_set_lower=ns,positive_family_lowers=sum(x>0 for x in fam.values()),robust_positive=p['W_lower']>0 and sum(x>0 for x in fam.values())>=3 and all(x>0 for x in ns.values()))
 markers=[]
 for m,k in itertools.product(['qwen','llama'],['CROSS_ACTOR','DISJOINT']):
  def ev(pt,f,con):return evidence(cix[pt,m,f,k,con])
  dn=ev('POLARITY','NO','PASSIVE_DELTA_N');dy=ev('POLARITY','YES','PASSIVE_DELTA_Y');an=ev('POLARITY','NO','ACTIVE_DELTA_N');vv=ev('WORDING','NO','PASSIVE_YES_MINUS_WEI');wp=ev('WORDING','NO','WEI_MINUS_PASSIVE_NO');ap=ev('WORDING','NO','ACTIVE_NO_MINUS_PASSIVE_NO');vy=ev('DISTRACTOR_VOICE','NO','PASSIVE_MINUS_ACTIVE_YES')
  asym=dn['W_lower']-dy['W_upper'];R=screenix[m,'YES'] and screenix[m,'NO'] and dn['robust_positive'] and asym>0;A=screenix[m,'NO'] and an['robust_positive'];V=screenix[m,'NO'] and vv['robust_positive']
  active_c={dw:next(x for x in profiles if (x['model'],x['fact'],x['condition'],x['distractor_voice'],x['distractor_wording'])==(m,'NO',k,'ACTIVE',dw))['all']['participant']['C'] for dw in ['YES','NO']}
  flags=dict(R=R,A=A,V=V,expanded_negation=R and A and V,exact_expression_dependence=R and wp['robust_positive'] and ap['robust_positive'],active_ceiling=all(x>=7 for x in active_c.values()) and vy['robust_positive'])
  markers.append(dict(model=m,condition=k,primary=m=='qwen' and k=='CROSS_ACTOR',supported=flags,evidence=dict(passive_Delta_N=dn,passive_Delta_Y=dy,asymmetry_lower=asym,active_Delta_N=an,passive_YES_minus_WEI=vv,WEI_minus_passive_NO=wp,active_NO_minus_passive_NO=ap,passive_minus_active_YES=vy,active_NO_target_role_C=active_c,single_YES_pass=screenix[m,'YES'],single_NO_pass=screenix[m,'NO']),identity='NONEXCLUSIVE_PROSPECTIVE_DESCRIPTIVE_LABELS_NOT_CONFIRMATION_OR_INTERNAL_MECHANISM'))
 replacements=[dict(pair_id=p['pair_id']+'-TO-WEI',original_call_id=p['challenge_call_id'],replacement_call_id=p['control_call_id'],model=p['model'],base_id=p['base_id'],fact=p['fact'],condition=p['condition'],contrast=p['contrast'],identity='AUTHOR_PREWRITTEN_WEI_INPUT_NOT_MODEL_REWRITE',**paired_detail(ix[p['challenge_call_id']],ix[p['control_call_id']])) for p in plan if p['contrast'] in ['PASSIVE_NO_MINUS_WEI','ACTIVE_NO_MINUS_WEI']]
 costs=[dict(model=m,actual_calls=0 if synthetic else len(rr),synthetic_rows=len(rr) if synthetic else 0,forwards=sum(r['raw']['row_forward_n'] for r in rr),input_tokens=sum(r['raw'].get('input_token_n',0) for r in rr),output_tokens=sum(r['raw'].get('generated_token_n',0) for r in rr),row_seconds=sum(r['raw'].get('row_seconds',0) for r in rr)) for m in ['qwen','llama'] for rr in [[r for r in rows if r['model']==m]]]
 summary=dict(experiment_id='EXP-20260908-B21',actual_model_outputs=0 if synthetic else 320,synthetic_rows=320 if synthetic else 0,actual_forwards=sum(r['row_forward_n'] for r in raw),single_screens=screens,profiles=profiles,comparisons=comparisons,markers=markers,costs=costs,independent_human_gold=0,automatic_B22=False,pair_count=len(pairs),replacement_count=len(replacements),pair_count_note='848 directed plan rows include 64 reverse contrast rows (32 WEI/NO and 32 active/passive NO); 784 distinct unordered call pairs. Reused controls and reverse rows are not independent samples or extra generations.')
 out.mkdir(parents=True,exist_ok=False)
 for n,x in [('ACTUAL-SCORED-ROWS.AI.json',rows),('PAIRED-TRANSITIONS.AI.json',pairs),('AUTHOR-TO-WEI-REPLACEMENTS.AI.json',replacements),('SUMMARY.json',summary)]: (out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
 return summary
if __name__=='__main__':
 s=analyze(Path(__file__).resolve().parent,Path(sys.argv[1]),Path(sys.argv[2]));print(json.dumps(s['markers']))
