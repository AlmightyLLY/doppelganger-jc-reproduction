from b19_prompt import prompt as previous_prompt, NAMES
def prompt(source,verb,target_label,names):
    text=previous_prompt("ZH",source,verb,target_label)
    old="人物名单："+"、".join(NAMES)
    assert text.count(old)==1 and len(names)==len(set(names))==4
    return text.replace(old,"人物名单："+"、".join(names),1)
