# B24 科学记录公开包

本包于 2026-09-09 从 B24 既有记录制作，供主窗口选择性公开归档。制作过程中没有调用模型、修改原件、执行 Git 或上传。本包不是新的实验、预注册或独立人审；不包含 B25。

## 完整数据与冻结结论

保留 **200 个来源、600 次新回答、3,600 次新 forwards、400 个评分对象**：每个来源有一次 ROLE_ONLY 和两次交换选项顺序的 CHOICE，合成一个 CHOICE 双序评分。没有历史回答复用。NEW 为六个谓词的 120 个来源，ANCHOR 为四个旧谓词的 80 个来源，两者分开报告。来源、调用和双序评分不是独立语言样本量；只有一个名单和两种角色映射。

`analysis-v1/RAW-RESPONSES.json` 逐字节保留源文、完整实际 messages、渲染提示、input/generated token IDs、真实生成回答及停止信息。原始文件 SHA256 为：

```text
226036a7288712cef395bd39351373e2acd117e60b81aee21fa2f3a897b520e4
```

`SOURCE-POSITIONS.json` 的 200 个来源、两份 600 调用计划、执行输入，以及 `analysis-v1/formal-v1/` 全部九个正式评分 JSON 均为原文件逐字节副本。所有失败、未决、单序与双序结果、分层和新增损害均保留。实际 messages 和 prompt 哈希同时与原计划和机械派生计划逐条核对一致。

冻结主要标签为 **P_NEW=false**：基础能力与总体交互通过，覆盖和保护失败。NEW 的 ROLE_ONLY 为 108C12W，CHOICE 双序为 112C2W6U；不能以总体任务差或 ANCHOR 结果替代主要预测成功。详细八格、分类未决识别界、词项/映射/位置分层及反例见完整评分文件与 `RESULT-ANALYSIS.PUBLIC.zh-CN.md`。识别界不是抽样置信区间。

## 科学规范与运行前澄清

`RUN-SPEC.json`、`SCORING-SPEC.zh-CN.md`、`R-ENDPOINT-CLARIFICATION.zh-CN.md` 均保持原字节。R 端点澄清是在模型调用为零、尚未上传科研包时记录的测量实现修正，不能称为看结果后修分。只有唯一对象中两个唯一字段都精确属于题目名单时，才分类为 R 或 NON_R；名单外、未知、缺失和不唯一情况归 U_R。原 B23 角色 C/W/U 评分保留不变。

`R-CLARIFICATION-VERIFICATION.json` 保留运行前协调合成复核，`SYNTHETIC-CHECK.json` 与 `check_b24.py` 保留 93 项合成走读及代码；合成文本不是模型回答。`FROZEN-SCIENCE-HASHES.PUBLIC.json` 保留所用科学来源在原冻结清单中的哈希和原清单时间。原规范较早的“可读人物”简述须结合最终澄清和评分规范理解。

`SCIENTIFIC-PROTOCOL.PUBLIC.zh-CN.md`、`SCORING-IMPLEMENTATION.PUBLIC.zh-CN.md` 和结果分析是明确的公开摘录，逐项清单记录原文行范围。运行组织、实验室环境及个人交付入口未摘录；摘录不是完整原件。原文的文件引用和历史工作边界保持其当时含义，不表示这些被引用原件都随本包公开。

## 复算

使用 Python 3 标准库：

```text
python recompute.py --output recomputed_scores
```

输出目录必须尚不存在。入口仅运行包内原字节的 `analyze_b24.py`、`scoring.py` 和 `score_b09.py`，将结果写到新目录，不修改公开或原冻结文件。制作本包时已单独复算一次：**九个正式 JSON 全部逐字节一致**，600 个回答、400 个评分及 P_NEW 的两项失败构件均一致，模型调用为零。详见 `RECOMPUTATION-VERIFICATION.json`。

`check_b24.py` 是原合成检查脚本，直接运行会写入所在目录的 `SYNTHETIC-CHECK.json`；若需重做合成检查，请先使用可丢弃的包副本。它不是上述冻结评分复算的必需步骤。

复算通过只证明：给定这些回答和冻结参考，公开代码重现既有评分。它不验证独立人工 gold、材料自然性、因果机制或跨环境生成稳定性。独立人工 gold 为 0。`INFERENCE-SPEC.PUBLIC.json` 保留模型 revision、文件内容哈希及科学推理策略；模型资产、tokenizer 实体、机器环境锁和执行驱动不随包公开，因此不承诺完整推理逐字节重现。

## 个人文档与公开边界

四个本人 Word/Excel 原件只登记去路径的文件内容 SHA256 和未审核事实，见 `PRIVATE-ARTIFACT-HASHES.PUBLIC.json`。内容哈希与当时原件字节核对一致；未提取、渲染或公开其中内容。当前本人意见为 24 个空白格，审核未完成；这不产生人工金标或本人认可。

本人原件、人审笔记、机器环境、账户、绝对本地或远程路径、连接/运行日志、封存及私有上游材料均不在本包。具体省略理由见 `OMISSIONS.json`。没有因隐私冲突删改任何实际科学提示或模型回答；如遇此类冲突，规则是停止公开该文件并登记，而非改写回答。

`SOURCE-PUBLIC-MANIFEST.json` 对每个文件列出仓库相对来源、原始和公开 SHA256、字节数及变换。新生成的说明和审计没有旧源文件，原始 SHA256 为 null。它覆盖除自身和 `MANIFEST-SHA256.txt` 外的全部文件；后者单独记录清单哈希。最终来源、字节、范围和扫描检查见 `PUBLICATION-VALIDATION.json`。扫描辅助确认当前包的边界，未来新增文件仍须另行审核。
