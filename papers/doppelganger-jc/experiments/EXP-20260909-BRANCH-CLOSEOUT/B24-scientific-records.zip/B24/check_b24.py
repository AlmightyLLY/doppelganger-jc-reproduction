"""Synthetic walkthrough only. No torch/model imports or forwards."""
from pathlib import Path
from fractions import Fraction as F
import json,copy,hashlib,itertools
from scoring import role_score,choice_score,choice_pair
from analyze_b24 import analyze,endpoint,cell,linear,KCOEF,support
P=Path(__file__).resolve().parent;rd=lambda n:json.loads((P/n).read_text());plan=rd('DERIVED-CALL-PLAN.json');calls=plan['calls'];src=rd('SOURCE-POSITIONS.json')['sources'];tests=[]
def check(name,actual,expected):
 assert actual==expected,(name,actual,expected);tests.append(dict(case=name,actual=actual,expected=expected,status='PASS'))
c=calls[0];a,b=c['target_pair'];other=next(v for v in c['entity_map'].values() if v not in [a,b]);j=lambda x:json.dumps(x,ensure_ascii=False)
for name,text,expected,rev in [('correct',j(dict(actor=a,undergoer=b)),'C','NON_R'),('reverse',j(dict(actor=b,undergoer=a)),'W','R'),('distractor_pair',j(dict(actor=b,undergoer=other)),'W','NON_R'),('external_person',j(dict(actor='山田',undergoer=b)),'U','U_R'),('repeat',j(dict(actor=a,undergoer=a)),'W','NON_R'),('null',j(dict(actor=None,undergoer=b)),'U','U_R'),('string_null',j(dict(actor='null',undergoer=b)),'U','U_R'),('missing',j(dict(undergoer=b)),'U','U_R'),('duplicate','{"actor":"'+a+'","actor":"'+b+'","undergoer":"'+b+'"}','U','U_R'),('invalid','{bad','U','U_R'),('multiple_objects',j(dict(actor=a,undergoer=b))+j(dict(actor=b,undergoer=a)),'U','U_R')]:
 s=role_score(text,c);check(name,s['labels']['participant'],expected);check(name+'_R',endpoint(s,c)['reversal'],rev);check(name+'_NA',s['labels']['occurrence'],'N/A_NOT_REQUESTED')
for text in ['无法判断','不清楚','Unclear','不知道','佐藤 高桥']:
 check('non_roster_'+text,endpoint(role_score(j(dict(actor=text,undergoer=b)),c),c)['reversal'],'U_R')
sc=role_score('说明：'+j(dict(actor=b,undergoer=a)),c);check('extra_prose_reversal',endpoint(sc,c)['reversal'],'R');check('extra_prose_format',sc['format_compliance'],'FAIL')
for text,label in [('A','C'),(' B ','W'),('A because','U'),('A/B','U'),('a','U'),('', 'U')]:check('choice_'+text,choice_score(text,'A')['label'],label)
for x,y in itertools.product('CWU',repeat=2):check('pair_'+x+y,choice_pair(dict(label=x,letter='A'),dict(label=y,letter='B'))['label'],x if x==y and x!='U' else 'U')
check('missing_pair',choice_pair(None,None)['status'],'NOT_RUN');check('partial_pair',choice_pair(dict(label='C',letter='A'),None)['status'],'INCOMPLETE_TECHNICAL')
def raw_for(selector=lambda c:False):
 out=[]
 for c in calls:
  text=(j(dict(actor=c['target_pair'][1],undergoer=c['target_pair'][0])) if selector(c) else j(dict(actor=c['target_pair'][0],undergoer=c['target_pair'][1]))) if c['task']=='ROLE_ONLY' else c['correct_option']
  out.append(dict(call_id=c['call_id'],messages=c['messages'],prompt_sha256=c['prompt_sha256'],generated_text=text))
 return out
baseline=analyze(raw_for());check('all_correct_P',baseline['cohorts']['NEW']['support']['P_NEW'],False);check('all_correct_K',baseline['cohorts']['NEW']['overall']['K']['lower'],0.0)
def challenge(c):return c['task']=='ROLE_ONLY' and c['cohort']=='NEW' and c['fact']=='NO' and c['distractor_fact']=='YES'
positive=analyze(raw_for(challenge));check('positive_full_pipeline',positive['cohorts']['NEW']['support']['P_NEW'],True);check('positive_K',positive['cohorts']['NEW']['overall']['K']['lower'],1.0)
for name,predicate in [('three_families',lambda c:c['verb_id'] in ['N01','N02','N03']),('one_mapping',lambda c:c['mapping_id']=='M1'),('one_position',lambda c:c['position']=='TARGET_FIRST')]:
 d=analyze(raw_for(lambda c:challenge(c) and predicate(c)));check(name,d['cohorts']['NEW']['support']['components']['coverage'],False)
d=analyze(raw_for(lambda c:challenge(c) and c['verb_id'] in ['N01','N02','N03','N04']));check('four_families',d['cohorts']['NEW']['support']['P_NEW'],True)
d=analyze(raw_for(lambda c:c['task']=='ROLE_ONLY' and c['cohort']=='ANCHOR' and c['fact']=='NO' and c['distractor_fact']=='YES'));check('anchor_never_substitutes',d['cohorts']['NEW']['support']['P_NEW'],False);check('anchor_descriptive_K',d['cohorts']['ANCHOR']['overall']['K']['lower'],1.0)
for count,expected in [(1,True),(2,False)]:
 raw=raw_for(challenge);idx=[i for i,c in enumerate(calls) if c['cohort']=='NEW' and c['task']=='ROLE_ONLY' and c['condition']=='SINGLE' and c['fact']=='YES'][:count]
 for i in idx:raw[i]['generated_text']='null'
 d=analyze(raw);check('single_12minus'+str(count),d['cohorts']['NEW']['support']['components']['capability'],expected)
for task,fact in [('ROLE_ONLY','YES'),('CHOICE','YES'),('CHOICE','NO')]:
 for failures,expected in [(2,True),(3,False)]:
  raw=raw_for(challenge);ids=[s['source_id'] for s in src if s['cohort']=='NEW' and s['fact']==fact and s['condition']=='CROSS_ACTOR'][:failures]
  for i,c in enumerate(calls):
   if c['source_id'] in ids and c['task']==task:raw[i]['generated_text']='null'
  d=analyze(raw);check('protection_'+task+fact+str(failures),d['cohorts']['NEW']['support']['components']['protection'],expected)
empty=analyze([]);check('all_NOT_RUN',sum(a['status']=='NOT_RUN' for a in empty['answers']),600);check('missing_not_U',sum(r['reversal']=='U_R' for r in empty['records']),0);check('missing_P_none',empty['cohorts']['NEW']['support']['P_NEW'],None)
r=raw_for();partial=analyze(r[1:],[c['call_id'] for c in calls]);check('started_unknown',partial['answers'][0]['status'],'STARTED_UNKNOWN');check('incomplete_K',partial['cohorts']['NEW']['support']['P_NEW'],None)
choiceidx=next(i for i,c in enumerate(calls) if c['task']=='CHOICE');d=analyze([x for i,x in enumerate(r) if i!=choiceidx]);check('partial_choice',next(p['CHOICE']['status'] for p in d['paired'] if p['source_id']==calls[choiceidx]['source_id']),'INCOMPLETE_TECHNICAL')
# Exhaustively enumerate all assignments of U for a constructed eight-cell contrast.
cells={k:dict(n=10,R=i%3,U_R=1,NON_R=9-i%3,status='COMPLETE') for i,k in enumerate(KCOEF)}
x=linear(cells,KCOEF);points=[sum(F(KCOEF[k]*(cells[k]['R']+bit),10) for k,bit in zip(KCOEF,bits)) for bits in itertools.product([0,1],repeat=8)];check('signed_U_lower',x['lower_exact'],str(min(points)));check('signed_U_upper',x['upper_exact'],str(max(points)))
# .10 is outside the n24 grid. Test the exact production gate with an exact synthetic n10 contrast.
q=positive['cohorts']['NEW'];
for rnum,den,expected in [(1,10,True),(99,1000,False)]:
 cs={k:dict(n=den,R=rnum if k==('ROLE_ONLY','NO','YES') else 0,U_R=0,status='COMPLETE') for k in KCOEF};ov=copy.deepcopy(q['overall']);ov['K']=linear(cs,KCOEF);ov['D']['ROLE_ONLY_NO']=linear(cs,{('ROLE_ONLY','NO','YES'):1,('ROLE_ONLY','NO','NO'):-1});res=support(q['single'],ov,q['families'],q['mappings'],q['positions'],q['protection']);check('K_boundary_'+str(rnum)+'_'+str(den),res['components']['interaction'],expected)
# Coefficient-wise U increment must affect lower only for negative coefficients, upper only for positive.
for key,sign in KCOEF.items():
 cs={k:dict(n=24,R=0,U_R=int(k==key),status='COMPLETE') for k in KCOEF};v=linear(cs,KCOEF);check('coefficient_'+str(key),(v['lower_exact'],v['upper_exact']),('-1/24','0') if sign<0 else ('0','1/24'))
(P/'SYNTHETIC-CHECK.json').write_text(json.dumps(dict(status='PASS',identity='SYNTHETIC_NOT_RESEARCH_OUTPUT',cases=tests,case_count=len(tests),forwards=0,scientific_calls=0),ensure_ascii=False,indent=2)+'\n');print('PASS',len(tests))
