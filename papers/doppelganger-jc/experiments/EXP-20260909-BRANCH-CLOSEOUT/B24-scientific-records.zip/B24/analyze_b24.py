"""B24 frozen prospective analysis. Pure CPU, never calls a model.
B23 C/W/U is unchanged. Exact reversal endpoint is separately recorded.
"""
from pathlib import Path
from collections import Counter
from fractions import Fraction as F
import json,sys
from scoring import role_score,choice_score,choice_pair,transition,ROLES
P=Path(__file__).resolve().parent
TASKS=['ROLE_ONLY','CHOICE'];FACTS=['YES','NO']
KCOEF={('ROLE_ONLY','NO','YES'):1,('ROLE_ONLY','NO','NO'):-1,('ROLE_ONLY','YES','YES'):-1,('ROLE_ONLY','YES','NO'):1,('CHOICE','NO','YES'):-1,('CHOICE','NO','NO'):1,('CHOICE','YES','YES'):1,('CHOICE','YES','NO'):-1}
def endpoint(role,call):
 # Exact named reverse can be recognized even when a response contains extra prose.
 # Preserve B23 scoring; do not turn a clearly different named pair into target reversal.
 pair=[role['raw_fields'].get(k) for k in ['actor','undergoer']]
 readable=role['unique_readable_object'] and all(role['field_identity_reasons'][k]=='UNIQUE' for k in ['actor','undergoer']) and all(isinstance(v,str) and v in call['entity_map'].values() for v in pair)
 if not readable:return dict(reversal='U_R',reversal_reason='NON_ROSTER_OR_UNREADABLE_OR_NONUNIQUE_FIELD',raw_pair=pair,unique_readable_object=role['unique_readable_object'],field_identity_reasons=role['field_identity_reasons'],non_roster_fields=[k for k,v in zip(['actor','undergoer'],pair) if not isinstance(v,str) or v not in call['entity_map'].values()])
 return dict(reversal='R' if pair==call['target_pair'][::-1] else 'NON_R',reversal_reason='EXACT_TARGET_REVERSED' if pair==call['target_pair'][::-1] else 'OTHER_READABLE_PAIR',raw_pair=pair)
def cell(rows):
 c=Counter(r['label'] for r in rows);e=Counter(r['reversal'] for r in rows);n=len(rows);miss=sum(r['status']!='COMPLETE' for r in rows)
 assert n and e['R']+e['NON_R']+e['U_R']+miss==n
 return dict(n=n,C=c['C'],W=c['W'],U=c['U'],not_scored=miss,R=e['R'],NON_R=e['NON_R'],U_R=e['U_R'],status='INCOMPLETE_TECHNICAL' if miss else 'COMPLETE',lower=None if miss else e['R']/n,upper=None if miss else (e['R']+e['U_R'])/n)
def linear(cells,coefficients):
 selected=[(k,cells[k],a) for k,a in coefficients.items()]
 if any(c['status']!='COMPLETE' for k,c,a in selected):return dict(status='INCOMPLETE_TECHNICAL',point=None,lower=None,upper=None,lower_exact=None,upper_exact=None)
 point=sum((a*F(c['R'],c['n']) for k,c,a in selected),F(0));lo=sum((a*F(c['R']+(c['U_R'] if a<0 else 0),c['n']) for k,c,a in selected),F(0));hi=sum((a*F(c['R']+(c['U_R'] if a>0 else 0),c['n']) for k,c,a in selected),F(0))
 return dict(status='COMPLETE',point=float(point),lower=float(lo),upper=float(hi),lower_exact=str(lo),upper_exact=str(hi),point_identity='OBSERVED_R_LINEAR_CONTRAST_NOT_IMPUTED_U',interval_identity='CLASSIFICATION_IDENTIFICATION_NOT_CONFIDENCE_INTERVAL')
def contrast(rows):
 cells={(t,f,d):cell([r for r in rows if (r['task'],r['fact'],r['distractor_fact'])==(t,f,d)]) for t in TASKS for f in FACTS for d in FACTS}
 ds={t+'_'+f:linear(cells,{(t,f,'YES'):1,(t,f,'NO'):-1}) for t in TASKS for f in FACTS}
 return dict(cells=[dict(task=k[0],fact=k[1],distractor_fact=k[2],K_coefficient=KCOEF[k],**c) for k,c in cells.items()],D=ds,K=linear(cells,KCOEF))
def support(singles,overall,families,mappings,positions,protection):
 allcontrasts=[overall,*families.values(),*mappings.values(),*positions.values()]
 complete=all(c['not_scored']==0 for c in [*singles.values(),*protection.values()]) and all(x['K']['status']=='COMPLETE' for x in allcontrasts)
 def positive(x):return F(x['K']['lower_exact'])>0 if x['K']['lower_exact'] is not None else None
 flags=dict(capability=all(c['C']>=11 for c in singles.values()) if all(not c['not_scored'] for c in singles.values()) else None,
 interaction=(F(overall['K']['lower_exact'])>=F(1,10) and F(overall['D']['ROLE_ONLY_NO']['lower_exact'])>0) if overall['K']['status']=='COMPLETE' else None,
 coverage=(sum(positive(x) for x in families.values())>=4 and all(positive(x) for x in [*mappings.values(),*positions.values()])) if all(x['K']['status']=='COMPLETE' for x in allcontrasts[1:]) else None,
 protection=all(c['C']>=46 for c in protection.values()) if all(not c['not_scored'] for c in protection.values()) else None)
 return dict(status='COMPLETE' if complete else 'INCOMPLETE_TECHNICAL',P_NEW=all(flags.values()) if complete else None,components=flags,failed_components=[k for k,v in flags.items() if v is False],incomplete_components=[k for k,v in flags.items() if v is None],single_counts=singles,protection_counts=protection,positive_family_n=sum(positive(x) is True for x in families.values()),family_positive={k:positive(v) for k,v in families.items()},mapping_positive={k:positive(v) for k,v in mappings.items()},position_positive={k:positive(v) for k,v in positions.items()},cohort='NEW_ONLY_ANCHOR_NEVER_SUBSTITUTES')
def aggregate(records):
 cohorts={};counts=[];losses=[]
 for cohort,nwords in [('NEW',6),('ANCHOR',4)]:
  rr=[r for r in records if r['cohort']==cohort];ctx=[r for r in rr if r['condition']=='CROSS_ACTOR'];single=[r for r in rr if r['condition']=='SINGLE']
  assert len(rr)==nwords*40 and len(single)==nwords*8
  singles={t+'_'+f:cell([r for r in single if (r['task'],r['fact'])==(t,f)]) for t in TASKS for f in FACTS}
  overall=contrast(ctx);families={v:contrast([r for r in ctx if r['lexical_family']==v]) for v in sorted({r['lexical_family'] for r in rr})};maps={v:contrast([r for r in ctx if r['mapping_id']==v]) for v in ['M1','M2']};positions={v:contrast([r for r in ctx if r['position']==v]) for v in ['TARGET_FIRST','TARGET_LAST']}
  assert all(c['n']==nwords*4 for c in overall['cells']) and all(c['n']==nwords*2 for c in singles.values())
  protection={t+'_'+f:cell([r for r in ctx if (r['task'],r['fact'])==(t,f)]) for t,f in [('CHOICE','YES'),('CHOICE','NO'),('ROLE_ONLY','YES')]}
  assert all(c['n']==nwords*8 for c in protection.values())
  cohorts[cohort]=dict(single=singles,overall=overall,families=families,mappings=maps,positions=positions,protection=protection)
  if cohort=='NEW':cohorts[cohort]['support']=support(singles,overall,families,maps,positions,protection)
  for t in TASKS:
   for f in FACTS:
    for cond,ds in [('SINGLE',['NONE']),('CROSS_ACTOR',FACTS)]:
     for d in ds:
      sub=[r for r in rr if (r['task'],r['fact'],r['condition'],r['distractor_fact'])==(t,f,cond,d)]
      facets=[('all',['all']),('lexical_family',list(families)),('mapping_id',['M1','M2'])]+([] if cond=='SINGLE' else [('position',['TARGET_FIRST','TARGET_LAST'])])
      for facet,values in facets:
       for val in values:counts.append(dict(cohort=cohort,task=t,fact=f,condition=cond,distractor_fact=d,facet=facet,value=val,**cell([r for r in sub if facet=='all' or r[facet]==val])))
  for r in ctx:
   base=next(s for s in single if (s['task'],s['base_id'],s['fact'])==(r['task'],r['base_id'],r['fact']))
   losses.append(dict(source_id=r['source_id'],single_source_id=base['source_id'],cohort=cohort,task=r['task'],fact=r['fact'],lexical_family=r['lexical_family'],mapping_id=r['mapping_id'],position=r['position'],distractor_fact=r['distractor_fact'],transition=transition(base['label'],r['label']),single_reversal=base['reversal'],context_reversal=r['reversal']))
 return dict(cohorts=cohorts,cells=counts,single_to_context=losses)
def analyze(raw,started_call_ids=None):
 plan=json.loads((P/'DERIVED-CALL-PLAN.json').read_text());calls=plan['calls'];sources=json.loads((P/'SOURCE-POSITIONS.json').read_text())['sources'];source={s['source_id']:s for s in sources};lookup={c['call_id']:c for c in calls};actual={r['call_id']:r for r in raw};assert len(raw)==len(actual) and set(actual)<=set(lookup);started=set(actual if started_call_ids is None else started_call_ids);assert set(actual)<=started<=set(lookup)
 scored={};answers=[]
 for c in calls:
  r=actual.get(c['call_id']);sc=None
  if r is not None:
   assert r['messages']==c['messages'] and r['prompt_sha256']==c['prompt_sha256'] and isinstance(r['generated_text'],str)
   sc=role_score(r['generated_text'],c) if c['task']=='ROLE_ONLY' else choice_score(r['generated_text'],c['correct_option'])
  scored[c['call_id']]=sc;answers.append(dict(plan=c,status='COMPLETE' if r is not None else 'STARTED_UNKNOWN' if c['call_id'] in started else 'NOT_RUN',actual=r,score=sc))
 records=[];paired=[]
 for g in plan['groups']:
  s=source[g['source_id']];meta={k:s[k] for k in ['source_id','base_id','lexical_family','cohort','mapping_id','fact','condition','position','distractor_fact']};role=scored[g['ROLE_ONLY']];rev=endpoint(role,lookup[g['ROLE_ONLY']]) if role else dict(reversal=None,reversal_reason='NOT_SCIENTIFICALLY_SCORED')
  rr=dict(**meta,task='ROLE_ONLY',status='COMPLETE' if role else 'STARTED_UNKNOWN' if g['ROLE_ONLY'] in started else 'NOT_RUN',label=role['labels']['participant'] if role else None,score=role,call_ids=[g['ROLE_ONLY']],**rev);records.append(rr)
  pair=choice_pair(scored[g['CHOICE_A']],scored[g['CHOICE_B']]);
  if pair['status']=='NOT_RUN' and any(g[k] in started for k in ['CHOICE_A','CHOICE_B']):pair['status']='INCOMPLETE_TECHNICAL'
  cr=dict(**meta,task='CHOICE',**pair,call_ids=[g['CHOICE_A'],g['CHOICE_B']],reversal={'C':'NON_R','W':'R','U':'U_R',None:None}[pair['label']]);records.append(cr);paired.append(dict(**meta,ROLE_ONLY=rr,CHOICE=cr,interpretation='TASK_CONDITION_COMPARISON_NOT_REPAIR_RATE'))
 result=aggregate(records);result.update(answers=answers,records=records,paired=paired,choice_order_diagnostics=dict(Counter(str(r.get('reason')) for r in records if r['task']=='CHOICE')),choice_fixed_letter=dict(Counter(str(r.get('fixed_letter')) for r in records if r['task']=='CHOICE')),identity='AUTHOR_AI_PROSPECTIVE_DEVELOPMENT_NOT_HUMAN_GOLD')
 return result
if __name__=='__main__':
 p=json.loads(Path(sys.argv[1]).read_text());o=Path(sys.argv[2]);o.mkdir(exist_ok=False)
 for k,v in analyze(p['rows'],p.get('started_call_ids')).items():(o/(k.upper()+'.AI.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
