# B24 评分冻结说明

B23 scoring.py 与 score_b09.py 原字节保持，ROLE 的角色、方向、人物集合、格式及语言分项不变，occurrence/record 为 N/A_NOT_REQUESTED。CHOICE strip 后仅大写单字母 A/B 合法；双序 C/C 为 C、W/W 为 W，混合为顺序 U，任一解析 U 为解析 U。单次原分和固定字母保留。

反转端点完全依 R-ENDPOINT-CLARIFICATION.zh-CN.md 的 Main 裁定：唯一可读对象中 actor 和 undergoer 各唯一、且都是本题名单精确姓名才可分 R/NON_R。等于目标反向才 R；其他名单内对（含干扰、重复及其他组合）为 NON_R。非名单姓名、无法判断、不清楚、Unclear、null/字符串null、缺失或不唯一均 U_R。不扩黑名单、不事后语义补判。说明文字在唯一对象之外时内容沿 B23，格式另列。技术未运行/不完整/未知启动的 reversal=null，绝不改作 U_R。

analyze_b24.py 从完整600计划生成600回答位置与400评分。cell按计划分母保留 R/NON_R/U_R、C/W/U及not_scored；含技术缺失的差与标签为INCOMPLETE，不删分母。K八格系数与Main一致，正项下界取R/n、负项取(R+U_R)/n；上界相反。Fraction进行精确边界判定，浮点只作展示。识别界不是置信区间，观察R的线性差不是将U推定为0。

唯一NEW支持标签保留四构件与具体计数/失败/未完成原因；ANCHOR只描述。按六词、两映射、两位置分层，保留全部8格，另存每条件计数、SINGLE到上下文损害和逐来源两任务对照。不能将任务对照称自由生成修复率。
