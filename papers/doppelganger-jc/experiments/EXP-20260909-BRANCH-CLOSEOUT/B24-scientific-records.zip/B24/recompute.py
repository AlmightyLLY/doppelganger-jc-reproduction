"""Recompute B24's frozen descriptive scores from the public raw records.

Python 3 standard library only. No model calls. Output must be a new directory.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).resolve().parent
    output = args.output / 'formal-v1'
    subprocess.run(
        [sys.executable, str(root / 'analyze_b24.py'),
         str(root / 'analysis-v1' / 'RAW-RESPONSES.json'), str(output)],
        cwd=root, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
        check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )
    frozen = root / 'analysis-v1' / 'formal-v1'
    expected = {p.name for p in frozen.glob('*.json')}
    actual = {p.name for p in output.glob('*.json')}
    comparisons = []
    for name in sorted(expected | actual):
        before = (frozen / name).read_bytes() if name in expected else None
        after = (output / name).read_bytes() if name in actual else None
        comparisons.append({
            'file': name,
            'frozen_sha256': sha(before) if before is not None else None,
            'recomputed_sha256': sha(after) if after is not None else None,
            'byte_identical': before is not None and before == after,
            'json_equal': before is not None and after is not None
                          and json.loads(before) == json.loads(after),
        })
    passed = all(row['byte_identical'] for row in comparisons)
    records = json.loads((output / 'RECORDS.AI.json').read_text())
    answers = json.loads((output / 'ANSWERS.AI.json').read_text())
    support = json.loads((output / 'COHORTS.AI.json').read_text())['NEW']['support']
    report = {
        'identity': 'PUBLIC_ONLY_FROZEN_SCORE_RECOMPUTATION',
        'status': 'PASS' if passed else 'FAIL',
        'formal_json_files': len(comparisons),
        'all_files_byte_identical': passed,
        'all_files_json_equal': all(row['json_equal'] for row in comparisons),
        'answers': len(answers),
        'scored_positions': len(records),
        'P_NEW': support['P_NEW'],
        'components': support['components'],
        'failed_components': support['failed_components'],
        'model_calls': 0,
        'human_gold_validation_performed': False,
        'scope': 'Existing frozen functions and references applied to unchanged raw output, including the pre-run clarified R endpoint; no generation rerun or independent semantic validation.',
        'files': comparisons,
    }
    (args.output / 'RECOMPUTATION-VERIFICATION.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in
                      ['status', 'formal_json_files', 'all_files_byte_identical',
                       'answers', 'scored_positions', 'P_NEW', 'failed_components', 'model_calls']}))
    if not passed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
