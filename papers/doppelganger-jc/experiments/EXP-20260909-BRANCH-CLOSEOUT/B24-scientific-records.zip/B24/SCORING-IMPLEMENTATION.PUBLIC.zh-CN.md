# B24 科学记录公开摘录

> PUBLIC_DERIVED：保留下列原科学段落，不是完整原件或新的预注册；未摘录的私人交付入口、运行环境及组织信息为 PUBLIC_OMITTED。实际消息和模型回答在独立文件中逐字节保留。R 端点最终口径另见原字节的 R-ENDPOINT-CLARIFICATION.zh-CN.md 与 SCORING-SPEC.zh-CN.md。

## 输入和调用边界

Main `SOURCE-POSITIONS.json` SHA256 `56771259d23a5c0a3aaf731cd69ed1ca876640d5ac4d079b4a5fa8c908a4ac73`，200来源；`CALL-PLAN.json` SHA256 `18670ff48828a3e450977b92817dc6faecb3272528df6057ea311f9b024480d7`，600实际消息。原Main文件保持字节不变；若运行器需要model/sequence/entity_map等元数据，可另生成明确机械派生计划，600调用ID/messages/prompt_sha256/参考必须逐项匹配原包，不覆盖来源文件或改变科学条件。

六NEW词批评/邀请/搀扶/阻拦/采访/逮捕，四ANCHOR词表扬/推荐/推搡/拍打；一个固定名单、两反向角色映射。目标恒R1，目标肯否、干扰肯否、前后位置在每词每映射完整交叉；SINGLE与上下文均保留。每源1 ROLE_ONLY、2交换正确选项位置的CHOICE，600新调用，没有旧输出复用、JOINT、第三模板或额外科学smoke。

运行器只接收必要ID/模型/顺序/完整消息，不传作者参考或正确选项。CHOICE双候选是正式题面，不混同离线金标。两个任务完全保持B23冻结模板，正常原生生成，无强制前缀、解释链、前次输出或选项串联。评分适配不得给ROLE输出偷偷补occurred；发生/完整评分为N/A_NOT_REQUESTED。

## 评分与分母

复用B23角色分项/人物集合/格式语言规则与严格A/B单次解析、双序C/C=C、W/W=W、其余U的规则。NOT_RUN、STARTED_UNKNOWN和INCOMPLETE_TECHNICAL单列，不能当科学U。

主量R为目标双方精确反转。Main运行前澄清见 `R-ENDPOINT-CLARIFICATION.zh-CN.md`：仅唯一对象内actor/undergoer字段各唯一且两值精确属于本题名单时分类，目标反向为R，其余名单内人物对为NON_R。任一非名单值（包括看似人名）、未知表述、null/字符串null、缺失或多对象/字段不唯一均U_R。对象外说明不改变明确人物内容分类，格式另列。CHOICE双序W是R，C是非R，U是U_R。每格区间[R/n,(R+U_R)/n]；这不是置信区间。

令D_t_NO=r(t,NO,D+)−r(t,NO,D−)，YES同理。主K=(D_ROLE_NO−D_ROLE_YES)−(D_CHOICE_NO−D_CHOICE_YES)。必须由八原始格按正负系数分别累加上下界；保留R、非R、U_R、C/W/U和完整分母，不以U=0或只统计W替代。

主要仅NEW：SINGLE两任务×两极性每格n12；每任务×目标极性×干扰极性上下文格n24；每任务/目标极性合并上下文n48。ANCHOR对应n8、n16、n32，另行描述不能替代NEW。

P_NEW完整保留四构件：四个NEW SINGLE至少11/12C；NEW K下界≥.10且D_ROLE_NO下界>0；至少4/6词K下界>0，两个映射及两个位置下界均>0；CHOICE肯定及否定上下文各至少46/48双序C，ROLE肯定上下文至少46/48C。分别记录每个失败构件和原始计数，不用一个布尔标签压缩全部信息，不把ANCHOR结果与NEW混合。

静态假设输出走读真实评分/分析函数，至少覆盖完整正确、反向、干扰对、外部人物、重复人、null/字符串null、缺失/重复键、非法JSON、选项A/B/解释/多标签/小写、双序组合、未启动/不完整、U界正负系数、.10边界、11/12与46/48边界、4/6覆盖、单映射/单位置失败、ANCHOR不能顶替NEW。合成材料明确标记、不产生研究forward。

